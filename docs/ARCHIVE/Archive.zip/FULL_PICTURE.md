# Membria CLI: The Full Picture

**What we're building:** Decision-aware AI development companion
**Why:** Prevent repeated mistakes, learn from outcomes, improve team calibration
**When:** 4 months (15-20 weeks across 3 phases)

---

## The Vision (From Documentation)

Membria transforms **stateless AI coding** (Claude Code) into **decision-aware AI coding** by:

1. **Recording decisions** with full context (alternatives, assumptions, predictions)
2. **Injecting history** into Claude Code before generation (avoid past mistakes)
3. **Validating code** against constraints (no custom JWT, respect antipatterns)
4. **Tracking outcomes** (PR merged, tests pass, incidents, 30-day stability)
5. **Updating calibration** (your team is 17% overconfident on libraries)
6. **Preventing bias** (firewall blocks overconfident/risky decisions)

---

## What We Have (Phase 0 - CURRENT)

✅ **FalkorDB Schema**
- 6 node types: Decision, Engram, CodeChange, Outcome, NegativeKnowledge, AntiPattern
- 18 analytics queries
- 78/78 tests passing

✅ **Decision Extractor** (3-level)
- Explicit decisions
- Rule-based signals
- Haiku structured extraction

✅ **Graph Storage**
- Cypher queries for decisions
- Relationships (made_in, implemented_in, resulted_in)

✅ **Basic Bias Detection**
- Pattern matching for 4 biases
- Risk scoring
- Recommendations

⚠️ **MCP Daemon**
- Started but not fully integrated
- No context injection yet
- No decision capture

---

## What's Missing (Phases 1-3)

### Phase 0.x (4-6 weeks) - Infrastructure
- [ ] Migrations (schema versioning)
- [ ] CodeDigger integration (pre-commit prevention)
- [ ] Anti-bias firewall (red flags + blocking)

### Phase 1 (4-5 weeks) - Decision Capture & MCP
- [ ] Task Router (auto-classify decisions)
- [ ] Decision Capture form (alternatives, assumptions, predictions)
- [ ] Decision Surface (pre-gen context panel)
- [ ] MCP context injection into Claude Code
- [ ] Post-generation validators
- [ ] Interactive capture workflow

### Phase 2 (4-5 weeks) - Learning from Outcomes
- [ ] PR/Commit linking
- [ ] Outcome capture layer (GitHub, CI, Jira, time)
- [ ] Calibration update system (Beta distributions)
- [ ] Assumption validation
- [ ] Team calibration profiles

### Phase 3 (4-6 weeks) - Advanced Safety
- [ ] Full anti-bias firewall
- [ ] Resonance detection (human + LLM bias alignment)
- [ ] LoRA adapter for team
- [ ] Causal discovery agent
- [ ] Analytics dashboard

---

## The Complete Workflow (After Phase 1)

```
Developer in Claude Code:
"Add REST API for user management"

↓ Task Router
DECISION detected (choose framework)

↓ Decision Surface shows:
✅ Express worked before (8 months)
❌ Custom middleware failed (security)
⚠️ Team is 17% overconfident
📊 Past decision success rate: 61%

↓ Developer clicks "Proceed"

↓ Interactive Capture:
Statement: "Use Fastify for REST API"
Alternatives: "Express (proven), Koa (minimal)"
Assumptions: "Fastify handles 10k req/s", ...
Predicted: "Stable API in 2 weeks"
Confidence: "75% (calibrated to 62%)"

↓ MCP Context Injection:
Claude Code receives system prompt:
  "DECISION: Use Fastify"
  "CONSTRAINTS: Avoid custom auth"
  "TEAM PATTERNS: /api/v1/ prefix"
  "ASSUMPTIONS: Validate performance"

↓ Claude Code generates code
With context injected

↓ Post-Generation Validation:
✅ Uses Fastify (matches decision)
✅ No custom auth (respects constraints)
✅ Performance notes included

↓ Code submitted, PR created
Decision auto-linked to PR

↓ Outcome Captured (after Days 1, 3, 14, 30):
Day 1: PR merged → POSITIVE signal
Day 3: Tests pass → POSITIVE signal
Day 30: Stable 99.9% uptime → SUCCESS

↓ Calibration Updated:
Prediction: "2 weeks", Actual: "2 weeks" ✅
Assumption: "10k req/s", Actual: "12k req/s" ✅
Team confidence: +17% → +14% (improving!)

↓ Next Time Similar Decision:
"System, we're doing REST API again"
Claude receives: "Last time you chose Fastify, it worked great"
```

---

## Why This Matters

### Without Membria:
```
Developer: "Let's use custom JWT"
Claude: "Sure, here's custom JWT" ❌
Result: Security bug, 2-week rewrite

Next project, 3 months later:
Developer: "Let's use custom JWT"
Claude: "Sure, here's custom JWT" ❌❌
Result: Same mistake again
```

### With Membria:
```
Developer: "Let's use custom JWT"
Claude sees context: "Tried this before?"
System: "Custom JWT removed 89% of time (20,470 repos)"
System: "YOUR TEAM tried 2x, removed 2x"
System: "Last attempt: security review failed 3 months ago"

Firewall: 🚫 BLOCK - 89% failure rate is critical

Developer: "Oh right, use passport-jwt instead"
Result: Correct implementation first try
```

---

## Files Created So Far

**Documentation:**
1. ✅ FALKORDB_SCHEMA.md - Graph architecture
2. ✅ VERSIONING_STRATEGY.md - Schema versioning
3. ✅ BIAS_DEFENSE_GAP_ANALYSIS.md - What firewall needs
4. ✅ CODEDIGGER_INTEGRATION_PLAN.md - Pre-commit prevention
5. ✅ CLARIFIED_ARCHITECTURE.md - CodeDigger vs Membria
6. ✅ THREE_PHASE_ROADMAP.md - Full 4-month plan
7. ✅ FULL_PICTURE.md - This document

**Code:**
1. ✅ graph.py - 31 methods for all node/relationship operations
2. ✅ graph_schema.py - Schema definitions
3. ✅ graph_queries.py - 18 analytics queries
4. ✅ models.py - 6 dataclasses updated
5. ✅ tests/test_graph_schema_integration.py - 21 tests

**Status:**
- 78/78 tests passing
- Zero regressions
- Ready for Phase 0.1 (Migrations + CodeDigger)

---

## Next Question

**Where do we start?**

**Option A: Start Phase 0 immediately**
- Week 1-2: Migrations
- Week 2-3: CodeDigger integration
- Week 3-4: Anti-bias firewall
- Then move to Phase 1

**Option B: Skip to Phase 1 planning**
- Finish Phase 0 foundation first (assumed done)
- Start detailed Phase 1 task breakdown
- Get alignment on Decision Capture UX

**Option C: Run Phase 0 in parallel**
- Start Phase 0.1 (migrations) this week
- Start Phase 1 planning simultaneously
- Ready for Phase 1 when Phase 0 done

---

**What's your call?** 🚀

Should we:
1. Detail Phase 1 tasks in depth?
2. Start Phase 0 work?
3. Understand something else first?
