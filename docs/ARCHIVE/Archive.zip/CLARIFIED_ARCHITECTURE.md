# Clarified: Membria + CodeDigger Architecture

**After reading backend/README.md, here's the accurate picture:**

---

## Two Separate Systems

### CodeDigger (Backend) 🔍
**What:** Production system analyzing GitHub
- Runs on GCP VM (8GB RAM, 4GB swap)
- Crawls 965+ repos with 155,933 commits
- 4-stage detection pipeline (Regex → AST → Context → GLM-4.6)
- Detected 7,761+ antipatterns so far
- **Endpoint:** `https://codedigger.membria.ai:4000`
- **Status:** Running continuously (PM2 managed)
- **Knowledge:** 25 antipatterns in `config/patterns.yaml`

### Membria CLI (Frontend) 🚀
**What:** Developer tool consuming CodeDigger data
- Installed locally on developer machine
- Pre-commit hook integration
- Consumes CodeDigger API (read-only)
- Adds team history from local FalkorDB graph
- Decision firewall (blocks/warns/allows)
- **Endpoint:** Talks to `https://codedigger.membria.ai:4000/api/`

---

## Key Difference from My Initial Plan

❌ **I thought:** Membria CLI runs its own detection pipeline
✅ **Actually:** Membria CLI consumes CodeDigger detection results

### Consequence for Implementation

```
My plan:              Correct approach:
┌──────────────────┐  ┌──────────────────┐
│ Membria CLI      │  │ Membria CLI      │
│ ├─ Regex match   │  │ ├─ Fetch patterns│
│ ├─ AST parse     │  │ │   from API     │
│ ├─ LLM validate  │  │ ├─ Match in diff │
│ └─ Store result  │  │ │   (Stage 1-3)  │
└──────────────────┘  │ └─ Show evidence │
                      │   from CodeDigger│
                      └──────────────────┘
    (Too complex!)        (Simple client!)
```

---

## The Integration Flow (Corrected)

```
1. Developer writes code
   └─> git add .

2. Developer runs git commit
   └─> Pre-commit hook triggers

3. Membria CLI (hook) executes:
   a) Check CodeDigger health
      GET /api/services → "Online"

   b) Load patterns from cache (or fetch)
      GET /api/patterns
      Cache for 24 hours

   c) Get staged diff
      git diff --cached

   d) Match patterns (Stage 1-3 logic only)
      For each pattern:
        - Regex match on keywords
        - Simple AST checks
        - Import validation
      NO LLM (CodeDigger already cached this)

   e) Get team history from local Graph
      MATCH (d:Decision)-[:USED_ANTIPATTERN]->(ap)
      WHERE ap.id = "custom_jwt"

   f) Fetch examples from CodeDigger
      GET /api/occurrences?pattern_id=custom_jwt

   g) Aggregate evidence
      - Industry stats (89% removal)
      - Team history (2x tried, 2x removed)
      - Recommendations

   h) Apply firewall decision
      IF removal_rate > 80% AND team_tried: BLOCK
      ELIF removal_rate > 50%: WARN
      ELSE: ALLOW

4. Show decision to developer
   ✅ PROCEED
   ⚠️  WARN (can --force)
   🚫 BLOCK (needs team lead)

5. Developer's response
   - If PROCEED: commit goes through ✅
   - If WARN: developer decides
   - If BLOCK: commit prevented, shows why
```

---

## What This Means for Development

### Simpler Than I Thought ✨
- No need to implement full 4-stage detection
- No need to maintain pattern definitions
- No LLM calls (cost-free!)
- Just API client + pattern matcher + firewall

### Faster Implementation
- **Week 1:** CodeDigger API client (fetch patterns, cache, health check)
- **Week 1-2:** Pattern matcher (Stage 1-3 logic) + evidence aggregator
- **Week 2-3:** Pre-commit hook integration + Graph queries
- **Week 3:** Anti-bias firewall
- **Week 4:** Testing + dogfooding

### Dependency
- Must have CodeDigger running and accessible
- If CodeDigger offline → graceful degradation (warn only)

---

## Files We'll Create/Modify

**New files in `src/membria/`:**
```
codedigger_client.py        # API client
pattern_matcher.py          # Stage 1-3 matching
evidence_aggregator.py      # Compile evidence
firewall.py                 # Block/warn/allow logic
hooks/pre-commit            # Git hook script
```

**Modified:**
```
graph.py                    # Add pattern query methods
models.py                   # Add PatternDetection dataclass
commands/antipattern.py     # New CLI command group
```

---

## API Endpoints We'll Use

| Endpoint | Purpose | When |
|----------|---------|------|
| `GET /health` | Check if CodeDigger is alive | On startup |
| `GET /api/patterns` | Fetch all 25 patterns | First run, cache 24h |
| `GET /api/stats` | Global stats (for dashboard) | Occasionally |
| `GET /api/occurrences` | Example instances | When showing evidence |
| `GET /api/services` | Pipeline health | Debug/status check |

---

## No Stage 4 LLM Calls From CLI

Why not?
1. **CodeDigger already cached it** - GLM-4.6 validation in Redis for 30 days
2. **Cost savings** - Don't pay for duplicate validation
3. **Simplicity** - Regex + AST + Context is enough for pre-commit
4. **Confidence lower but acceptable** - 0.85 vs 0.95 from full pipeline

When confidence matters:
- High confidence (>0.9) from CodeDigger examples → BLOCK
- Medium confidence (0.7-0.9) from our matching → WARN
- Low confidence (<0.7) → ALLOW but log

---

## Environment for Integration

**On Developer Machine:**
```bash
CODEDIGGER_URL=https://codedigger.membria.ai:4000
CODEDIGGER_CACHE_TTL=86400
MEMBRIA_FIREWALL_LEVEL=warn|block
```

**On CodeDigger Server (already set up):**
```bash
DATABASE_URL=postgresql://...
REDIS_URL=redis://...
GITHUB_TOKEN=ghp_...
GLM4_API_KEY=...
PM2 processes running:
  - membria-miner (crawls GitHub)
  - membria-worker (processes diffs)
  - membria-diff-loader-1 to 4 (parallel loaders)
```

---

## Timeline (Revised & Realistic)

**Phase 0.1: CodeDigger Integration (3-4 days)**
- Day 1: CodeDigger client (fetch, cache, health check)
- Day 2: Pattern matcher (Stage 1-3 logic)
- Day 2-3: Evidence aggregator + Graph queries
- Day 3-4: Pre-commit hook + integration tests

**Phase 0.2: Migrations (2-3 days)**
- Version tracking + auto-migrate

**Phase 0.3: Anti-Bias Firewall (2-3 days)**
- Red flags + decision blocking

**Phase 1: Dogfooding (3-5 days)**
- Test on real project
- Fix bugs
- Documentation

**Total:** 10-15 days, ~2 weeks

---

## Success Criteria

✅ **Phase 0.1 Complete:**
- CLI fetches patterns from CodeDigger API
- Pre-commit hook detects antipatterns in staged code
- Evidence shows industry stats + team history
- Critical patterns block commit, warn patterns can override
- All 78 tests passing + 20+ new integration tests

✅ **Ready for Phase 1:**
- Can dogfood on real Membria development
- Learn our own antipatterns
- Calibrate firewall levels

---

## Next Steps

1. **Confirm:** CodeDigger accessible at `https://codedigger.membria.ai:4000`?
2. **Confirm:** Can I access the API endpoints (no auth required)?
3. **Decide:** Option A (Migrations first) or integrate CodeDigger immediately?
4. **Start:** Pick the first task and go!

🚀 **Ready to build!**
