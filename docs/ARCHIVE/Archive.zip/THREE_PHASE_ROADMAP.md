# Membria CLI: Three-Phase Roadmap to Full Superagent

**Total Timeline:** 12-16 weeks (3 months)

---

## Phase 0: Foundation (3-4 weeks) ✅ Starting

**Goal:** Core infrastructure ready
- ✅ FalkorDB schema (6 node types, 18 queries)
- Migration system (versioning, rollback)
- CodeDigger integration (pre-commit prevention)
- Anti-bias firewall (red flags, blocking)

**Deliverable:** Pre-commit hook prevents bad patterns

---

## Phase 1: Decision Capture & MCP Integration (4-5 weeks)

**Goal:** Full decision recording with context injection to Claude Code

### 1.1 Task Router (Decision Classification)
**What:** Auto-detect if user action is tactical, decision, or learning

**Files:**
```
NEW:
  src/membria/task_router.py
  tests/test_task_router.py

MODIFY:
  src/membria/extractor/decision_extractor.py
  src/membria/mcp_daemon.py
```

**Implementation:**
```python
class TaskRouter:
    """Classify user requests into task types"""

    def classify(self, user_input: str, context: str) -> TaskClassification:
        """Returns: TACTICAL | DECISION | LEARNING"""
        # Check for decision signals
        #   - "choose", "decide", "which is better"
        #   - "should we", "what if"
        #   - Multiple alternatives mentioned
        #   - Architecture keywords: "pattern", "design", "structure"
        #
        # If decision → trigger full Membria flow
        # If tactical → direct code generation
        # If learning → link outcome to past decision
```

**CLI Commands:**
```bash
membria extractor classify --text "Add JWT authentication"
# → DECISION (vs TACTICAL vs LEARNING)
```

### 1.2 Decision Capture Form (Full Context)
**What:** Extended decision record with alternatives, assumptions, predictions

**Files:**
```
NEW:
  src/membria/decision_capture.py
  src/membria/commands/capture.py
  tests/test_decision_capture.py

MODIFY:
  src/membria/models.py (enhance Decision model)
  src/membria/graph.py (update add_decision method)
```

**Enhanced Decision Model:**
```python
@dataclass
class Decision:
    decision_id: str
    statement: str
    alternatives: List[str]  # ← Already have
    confidence: float  # ← Already have

    # NEW FIELDS:
    alternatives_with_reasons: Dict[str, str]
    # {
    #   "Express.js": "Slower but proven",
    #   "Fastify": "Faster, team inexperienced",
    #   "Custom": "High risk per negative knowledge"
    # }

    assumptions: List[str]
    # [
    #   "Fastify can handle 10k req/s",
    #   "Team can learn it in 1 week",
    #   "Ecosystem has needed plugins"
    # ]

    predicted_outcome: Dict[str, Any]
    # {
    #   "description": "Stable, performant API in 2 weeks",
    #   "success_criteria": [
    #     "Handles 10k req/s",
    #     "No critical bugs in 30 days",
    #     "Team onboarding < 1 week"
    #   ],
    #   "risk_level": "medium"
    # }

    context_hash: str  # SHA256 of decision context (immutable)
```

**Interactive Capture Flow:**
```bash
membria capture start
# → Shows Decision Surface with history
# → Prompts:
#   1. Statement: "Use Fastify for REST API"
#   2. Alternatives: "Express.js (slower), Koa (minimal), Custom (high-risk)"
#   3. Why this one? "Better performance needed"
#   4. Assumptions: "Fastify handles 10k req/s", ...
#   5. Predicted outcome: "Stable API in 2 weeks", success criteria?
#   6. Confidence: "0.75 (but team is +17% overconfident, so 0.62)"
#   7. Context hash: Auto-generated
#
# Saves as Decision node in Graph
```

### 1.3 Decision Surface (Pre-Generation Context)
**What:** Inline panel in IDE showing relevant history BEFORE code generation

**Files:**
```
NEW:
  src/membria/decision_surface.py
  src/membria/commands/surface.py
  vscode-extension/  (new VS Code extension)

MODIFY:
  mcp_daemon.py (expose surface API)
```

**What it Shows:**
```
┌──────────────────────────────────────────────┐
│ 🧠 Membria Decision Context                   │
│                                               │
│ 📊 RELEVANT HISTORY                           │
│ ✅ Express.js worked (8 months ago)           │
│ ❌ Custom middleware failed (security)        │
│ ⚠️ NEGATIVE KNOWLEDGE: Avoid custom auth      │
│                                               │
│ 📈 TEAM CALIBRATION                          │
│ You're 17% overconfident on lib choices      │
│ If confident 80% → likely ~65% success      │
│                                               │
│ [ Proceed ] [ Review ] [ I'll decide ]       │
└──────────────────────────────────────────────┘
```

**Implementation:**
```python
class DecisionSurface:
    def generate_context(self, decision_candidate: DecisionCandidate) -> Context:
        """Fetch relevant history from Graph"""

        # 1. Find similar past decisions
        similar = self.graph.find_similar_decisions(
            decision_candidate.statement,
            threshold=0.7
        )

        # 2. Get team calibration for this domain
        calibration = self.graph.get_team_calibration(
            domain=decision_candidate.module
        )

        # 3. Get negative knowledge alerts
        alerts = self.graph.find_relevant_negative_knowledge(
            decision_candidate.statement
        )

        return Context(
            similar_decisions=similar,
            team_calibration=calibration,
            negative_knowledge=alerts
        )
```

### 1.4 MCP Context Injection
**What:** Pass decision context to Claude Code before generation

**Files:**
```
MODIFY:
  src/membria/mcp_daemon.py
  src/membria/mcp_server.py

NEW:
  src/membria/context_injector.py
```

**How it works:**
```
1. Developer triggers code generation in Claude Code
2. MCP daemon intercepts
3. Detects DECISION task (via Task Router)
4. Fetches decision context (Decision Surface)
5. Injects system prompt:
   "DECISION CONTEXT: You are implementing..."
   "CONSTRAINTS: DO NOT use..."
   "TEAM PATTERNS: This team uses..."
   "ASSUMPTIONS: The decision assumes..."
6. Claude Code generates with full context
```

**System Prompt Example:**
```
DECISION CONTEXT:
You are implementing a decision that has been captured.
Decision: "Use Fastify for REST API in user-service"

CONSTRAINTS FROM HISTORY:
❌ DO NOT implement custom authentication
   (Failed 2 months ago with security vulns)

✅ DO use passport-jwt or similar

TEAM PATTERNS:
• Explicit error handling preferred
• /api/v1/ prefix standard
• Zod for validation

ASSUMPTIONS TO VALIDATE:
• Fastify handles 10k req/s
• Team learns it in 1 week
• Needed plugins available

NEGATIVE KNOWLEDGE:
• Custom crypto fails 89% of time
• forEach+async breaks async order
```

### 1.5 Post-Generation Validators
**What:** Check generated code matches decision and respects constraints

**Files:**
```
NEW:
  src/membria/validators/decision_consistency.py
  src/membria/validators/negative_knowledge_check.py
  src/membria/validators/bias_in_code.py
  tests/test_validators.py
```

**Checks:**
```python
class DecisionValidator:
    def validate_code_matches_decision(self, code: str, decision: Decision) -> bool:
        """Is generated code using the right framework?"""
        # Check: code mentions "Fastify", not "Express"

    def validate_negative_knowledge_respected(self, code: str) -> bool:
        """Any antipatterns in generated code?"""
        # Check: no custom JWT, no eval(), no forEach+async

    def validate_alternatives_considered(self, code: str, decision: Decision) -> bool:
        """Are alternatives at least mentioned in comments?"""
        # Check: code has "considered Express but chose Fastify..."
```

**Results:**
```
✅ Decision consistency: Uses Fastify ✓
✅ Negative knowledge: No custom auth ✓
✅ Assumptions addressed: Performance notes ✓
⚠️ Bias check: "definitely scales" is overconfident (log for calibration)
```

### 1.6 Tests & Integration
```python
def test_task_router_detects_decision():
def test_decision_capture_saves_all_fields():
def test_decision_surface_shows_history():
def test_mcp_injects_context():
def test_validators_catch_antipatterns():
def test_full_phase1_workflow():
```

---

## Phase 2: Outcome Capture & Calibration (4-5 weeks)

**Goal:** Track decision results and learn from them

### 2.1 PR/Commit Linking
**What:** Auto-link decisions to GitHub PRs and commits

**Files:**
```
NEW:
  src/membria/github_client.py
  src/membria/git_hooks/post-commit
  tests/test_github_linking.py
```

**How:**
```
1. Developer commits code
2. Post-commit hook runs
3. Finds decision_id in commit message: "Implement JWT decision dec_142"
4. Queries Decision node from Graph
5. Updates decision.linked_pr, decision.linked_commit
6. Sets status: PENDING_OUTCOME → EXECUTED
```

**CLI:**
```bash
membria commit --decision dec_142 -m "Use Fastify for API"
# → Auto-finds PR, links it
```

### 2.2 Outcome Capture Layer
**What:** Listen for events (PR merged, tests fail, incidents) and record outcomes

**Files:**
```
NEW:
  src/membria/outcome_capture/
    ├─ __init__.py
    ├─ github_listener.py  (PR events)
    ├─ ci_listener.py      (test/build events)
    ├─ jira_listener.py    (bug reports)
    ├─ incident_listener.py (PagerDuty)
    └─ time_listener.py    (30-day/90-day checks)

  src/membria/commands/outcome.py
  tests/test_outcome_capture.py
```

**Events Captured:**
```
Day 0: PR Created
  Decision status: SUBMITTED

Day 1: PR Merged
  Signal: POSITIVE (code accepted by reviewer)
  Status: MERGED

Day 3: CI Passes
  Signal: POSITIVE (technical validation)
  Tests: All green

Day 14: Bug Found (linked to PR)
  Signal: WEAK_NEGATIVE
  Severity: Low
  Description: "Plugin compatibility, fixed in 2 hours"

Day 30: Stability Window
  Signal: POSITIVE or NEGATIVE
  Metrics:
    - Uptime: 99.9%
    - P99 latency: 45ms
    - Throughput: 12k req/s (vs assumed 10k)
    - Bugs: 1 minor (resolved)

Final Outcome: SUCCESS / PARTIAL / FAILURE
```

**Implementation:**
```python
class OutcomeCapture:
    async def listen_github_events(self):
        """Listen for PR merged, closed, etc."""
        # Webhook from GitHub
        # Find linked Decision
        # Update outcome_signals

    async def listen_ci_events(self):
        """Listen for test pass/fail"""
        # From GitHub Actions, CircleCI, etc
        # Add signal: POSITIVE (pass) or NEGATIVE (fail)

    async def listen_jira_events(self):
        """Listen for bugs linked to commits"""
        # Find Decision by commit_sha
        # Add negative signal if bug related

    async def check_stability_windows(self):
        """Check 30-day and 90-day milestones"""
        # For each decision older than 30/90 days
        # Evaluate: Uptime? Performance? Incidents?
        # Record final outcome
```

### 2.3 Calibration Update System
**What:** Learn from outcomes to improve team's confidence estimates

**Files:**
```
NEW:
  src/membria/calibration/
    ├─ __init__.py
    ├─ calculator.py    (Beta distribution updates)
    ├─ updater.py       (Apply to Graph)
    └─ analyzer.py      (Generate insights)

  tests/test_calibration.py
```

**How Calibration Works:**
```
Team Historical Data:
├─ Library choices: avg confidence 0.78, actual success 0.61
│  → Team is 17% OVERCONFIDENT
│
├─ Database queries: avg confidence 0.85, actual success 0.82
│  → Well calibrated
│
└─ Authentication: avg confidence 0.72, actual success 0.45
   → Team is 27% OVERCONFIDENT

When someone says "80% confident":
├─ If choosing library: suggest 0.63 (80% - 17%)
├─ If writing query: suggest 0.80 (already accurate)
└─ If doing auth: suggest 0.53 (80% - 27%)
```

**Bayesian Update:**
```python
def update_calibration(decision: Decision, outcome: Outcome):
    """Apply Beta distribution update"""

    # Get domain calibration
    domain_calib = graph.get_calibration(decision.module)
    # Current: Beta(alpha=50, beta=30)
    # Represents: ~63% success (50/(50+30))

    # Outcome was SUCCESS
    # Add weighted evidence
    weight = recency_weight(decision.created_at) × context_match_score

    # Update to Beta(alpha+weight, beta)
    # New distribution: ~65% success

    # Store in Graph
    graph.update_calibration_profile(decision.module, new_beta)
```

### 2.4 Assumption Validation
**What:** Track which assumptions held and which failed

**Files:**
```
NEW:
  src/membria/assumption_tracker.py
  tests/test_assumptions.py
```

**Example:**
```
Decision dec_142 Assumptions:
├─ "Fastify handles 10k req/s"
│  Status: VALIDATED ✅
│  Evidence: Achieved 12k req/s
│
├─ "Team learns Fastify in 1 week"
│  Status: VALIDATED ✅
│  Evidence: No onboarding issues
│
└─ "Ecosystem has needed plugins"
   Status: PARTIALLY_VALIDATED ⚠️
   Evidence: One compat issue, fixed in 2 hours

Next time someone proposes Fastify:
→ Show: "Previous assumptions mostly held"
→ Suggest: "Plan for 1 plugin compat issue"
```

---

## Phase 3: Advanced Features (4-6 weeks)

**Goal:** Full cognitive safety and learning loops

### 3.1 Anti-Bias Firewall (Complete)
- Red flag detection (5 signals)
- Escalation matrix (Low → Critical)
- Team lead notifications
- Decision freezing

### 3.2 Resonance Detection
- Detect when user bias + LLM bias align
- Force deliberation (Devil's Advocate, Pre-Mortem)
- Max 2 interventions per session (prevent fatigue)

### 3.3 LoRA Adapter for Team
- If systematic calibration gap (>20%)
- Generate fine-tuned adapter
- Improves Claude Code recommendations

### 3.4 Causal Discovery
- When prediction fails, search for confounders
- Query external APIs for variables that changed
- Add new Variable nodes to Graph

### 3.5 Analytics Dashboard
- Team decision metrics
- Success rate by domain
- Calibration evolution
- Rework patterns
- Negative knowledge effectiveness

### 3.6 Knowledge Export
- Team's decision history
- Lessons learned (negative knowledge)
- Patterns that worked/failed
- Export as: JSON, PDF, Markdown

---

## Summary: What Gets Built When

```
PHASE 0 (3-4 weeks) — FOUNDATION
├─ FalkorDB schema ✅
├─ Migrations
├─ CodeDigger integration
└─ Anti-bias firewall

PHASE 1 (4-5 weeks) — DECISION CAPTURE & MCP
├─ Task Router (classify decisions)
├─ Decision Capture (full context)
├─ Decision Surface (pre-gen context)
├─ MCP Context Injection
├─ Post-Generation Validators
└─ Pre-commit prevention working ✅

PHASE 2 (4-5 weeks) — OUTCOME TRACKING
├─ PR/Commit Linking
├─ Outcome Capture Layer (GitHub, CI, Jira, time)
├─ Calibration Update System
├─ Assumption Validation
└─ Learn from results ✅

PHASE 3 (4-6 weeks) — ADVANCED
├─ Full Anti-Bias Firewall
├─ Resonance Detection
├─ LoRA Adapter
├─ Causal Discovery
├─ Analytics Dashboard
└─ Production ready ✅
```

---

## Total Effort

| Phase | Weeks | Focus | MVP Ready |
|-------|-------|-------|-----------|
| 0 | 3-4 | Infrastructure | ✓ Pre-commit works |
| 1 | 4-5 | Decision capture | ✓ Full recording |
| 2 | 4-5 | Outcome tracking | ✓ Learning begins |
| 3 | 4-6 | Advanced | ✓ Production |

**Total:** 15-20 weeks (~4 months)

**By end of Phase 1:** Can capture decisions and run Claude Code with context
**By end of Phase 2:** Can learn from outcomes and improve calibration
**By end of Phase 3:** Full cognitive safety with bias protection

---

## Critical Path

Cannot skip:
- Phase 0: Schema foundation (everything else builds on it)
- Phase 1: Decision capture (useless without recording decisions)
- Phase 2: Outcome capture (can't learn without results)

Can parallelize:
- Phase 0.1 (Migrations) + Phase 0.2 (CodeDigger) + Phase 0.3 (Firewall)
- Phase 1 tasks mostly independent
- Phase 2 tasks mostly independent
- Phase 3 tasks completely independent

---

**Ready to detail Phase 1 tasks?** 🚀
