# Membria CLI: Next 3-4 Weeks - Prioritized Roadmap

**Current Status:** Phase 0.0 COMPLETE (schema implementation + tests)
**Date:** 2026-02-11

---

## ⚡ THE CRITICAL QUESTION

Что реализовывать в каком порядке?

1. **Phase 0.1: Migrations** (Schema versioning - foundational)
2. **Phase 0.1b: CodeDigger Integration** (Pattern detection + evidence)
3. **Phase 0.2: Anti-Bias Firewall** (Decision blocking)
4. **Phase 1: Dogfooding** (Real project testing)

---

## OPTION A: Migrations First → CodeDigger → Firewall

```
Week 1: Migrations (foundational - needed for safe schema changes)
  ├─ Migration runner
  ├─ v0.1.0 initial schema
  ├─ v0.2.0 add Engram nodes
  ├─ Version check on startup
  └─ New db commands (migrate, rollback, validate)
     Time: 2-3 days
     Value: CRITICAL (blocks other work)

Week 1-2: CodeDigger Integration (evidence collection)
  ├─ CodeDigger API client
  ├─ Pattern detection in diffs
  ├─ Evidence formatting
  ├─ Pre-commit hook
  └─ Graph storage of patterns
     Time: 3-4 days
     Value: HIGH (pre-commit prevention)

Week 2-3: Anti-Bias Firewall (decision blocking)
  ├─ Red flag detection (5 signals)
  ├─ Escalation matrix
  ├─ Decision firewall (blocks/warns/allows)
  ├─ Team lead notifications
  └─ Integration tests
     Time: 2-3 days
     Value: HIGH (bias prevention)

Week 3-4: Dogfooding & Polish
  ├─ Run on own project
  ├─ Real FalkorDB tests
  ├─ Bug fixes
  └─ Documentation
     Time: 3-5 days
     Value: VALIDATION
```

**Total:** 4-5 weeks
**Readiness:** Phase 1 dogfooding → Phase 2 real tests

---

## OPTION B: CodeDigger First → Migrations → Firewall (UPDATED!)

**⚠️ NEW INFO: CodeDigger is simpler than expected!**

After reading backend/README.md:
- We're just consuming an API (not building detection)
- No LLM calls needed (CodeDigger caches them)
- Pattern matching is Stage 1-3 only (regex, AST, context)
- **Much simpler & faster implementation**

```
Week 1: CodeDigger Integration (simple API client)
  ├─ CodeDigger API client (fetch, cache, health)      [1 day]
  ├─ Pattern matcher (Stage 1-3 logic)                 [1 day]
  ├─ Evidence aggregator (industry + team history)     [1 day]
  ├─ Pre-commit hook integration                       [1 day]
  └─ Integration tests
     Time: 3-4 days (SIMPLER than thought!)
     Value: HIGH (dev sees results immediately)

Week 1-2: Migrations (foundational support)
  ├─ Migration runner
  ├─ Versioning + auto-migrate
  └─ Tests
     Time: 2-3 days
     Value: CRITICAL (safety for schema changes)

Week 2-3: Anti-Bias Firewall (full defense)
  ├─ Red flag detection (5 signals)
  ├─ Escalation matrix (Low → Critical)
  ├─ Decision blocking + team lead notification
  └─ Tests
     Time: 2-3 days
     Value: HIGH (Phase 3 requirement)

Week 3-4: Dogfooding
     Time: 3-5 days
```

**Total:** 4-5 weeks
**Readiness:** CodeDigger working FAST, then migrations secure it, then firewall completes defense

---

## OPTION C: Firewall First → Migrations → CodeDigger

```
Week 1: Anti-Bias Firewall (most spec-critical)
  ├─ Red flags (5 signals)
  ├─ Decision blocking
  ├─ Escalation matrix
  └─ Tests
     Time: 2-3 days
     Value: CRITICAL (Phase 3 requirement)

Week 1-2: Migrations (foundational)
  ├─ Migration runner
  ├─ Versioning
  └─ Auto-migrate
     Time: 2-3 days

Week 2-3: CodeDigger Integration (evidence)
  ├─ API client
  ├─ Pattern detection
  ├─ Evidence formatting
  └─ Pre-commit hook
     Time: 3-4 days

Week 3-4: Dogfooding
     Time: 3-5 days
```

**Total:** 4-5 weeks
**Readiness:** Firewall complete early, CodeDigger adds evidence later

---

## MY RECOMMENDATION: Option B (CodeDigger First) 🚀

### Why? (Updated after clarification)

1. **CodeDigger is Simpler Than Expected**
   - Just API client + pattern matching (Stage 1-3)
   - No LLM calls (CodeDigger cached them)
   - 3-4 days, not 5-7 days
   - **Immediate visible value** to developers

2. **Migrations Can Wait (But Not Long)**
   - Needed before we modify schema
   - Simple implementation (2-3 days)
   - Foundation, not blocker for CodeDigger

3. **Fast Feedback Loop**
   - Developers see pre-commit prevention working
   - We learn antipatterns in our own code
   - Validates entire integration before firewall

4. **Firewall Benefits from Real Data**
   - Pre-commit logs inform firewall tuning
   - Real team history to test against
   - Not building blind

### Timeline (Option B - Recommended):

```
THIS WEEK (remaining 2-3 days):
  CodeDigger client + pattern matcher

NEXT WEEK (3 days):
  Evidence aggregator + pre-commit hook
  Integration tests
  → Pre-commit prevention WORKING

WEEK 2 (2-3 days):
  Migrations (schema versioning)
  Auto-migrate on startup

WEEK 3 (2-3 days):
  Anti-Bias Firewall
  Red flags + decision blocking

WEEK 4 (3-5 days):
  Dogfooding on own project
  Real FalkorDB tests
  Polish

→ Phase 1 ready (2-3 weeks)
```

**Advantages:**
- ✅ Visible progress early (Week 1)
- ✅ Real feedback from pre-commit
- ✅ Time to fix bugs before migrations
- ✅ Firewall tuned on real data
- ✅ Production-ready by Week 4

---

## YOUR DECISION: Which direction?

**Questions for you:**

1. **CodeDigger Server:**
   - Is it running at `localhost:3000`?
   - Or different host/port?
   - Does it need auth?

2. **Priority:**
   - Want immediate visible value (CodeDigger first)?
   - Or solid foundation first (Migrations first)?
   - Or compliance first (Firewall first)?

3. **Timeline:**
   - Can dedicate 4-5 weeks?
   - Or need something sooner?

4. **Dogfooding:**
   - Ready to test on actual project?
   - Or want more stability first?

---

## What Each Phase Enables

### After Migrations ✅
- Safe schema updates
- Version tracking
- Rollback capability
- CI/CD confidence

### After CodeDigger ✅✅
- Pre-commit prevention
- Team learns patterns
- Quantitative evidence
- Reduced rework

### After Firewall ✅✅✅
- Decision blocking (not just alerts)
- Escalation to team lead
- Red flag detection
- Cognitive bias prevention

### After Dogfooding ✅✅✅✅
- Real-world validation
- Bug fixes
- Performance tuning
- Production ready

---

## Current Spec Coverage

| Component | Coverage | Status |
|-----------|----------|--------|
| Graph Schema | 100% | ✅ DONE (Phase 0.0) |
| Decision Extraction | 70% | ✅ Working (not perfect) |
| Statistics | 80% | ✅ Queries exist |
| Calibration | 60% | ⚠️ Basic only |
| **Migrations** | 0% | ❌ MISSING |
| **CodeDigger** | 0% | ❌ MISSING |
| **Anti-Bias Firewall** | 15% | ⚠️ Partial (only patterns) |
| **Red Flags** | 0% | ❌ MISSING |
| **Cognitive Safety** | 20% | ⚠️ Partial (pattern detection) |

---

## Files Already Created

**Documentation:**
- ✅ PHASE_0_0_COMPLETE.md - Schema implementation summary
- ✅ BIAS_DEFENSE_GAP_ANALYSIS.md - What's missing in cognitive safety
- ✅ CODEDIGGER_INTEGRATION_PLAN.md - How to integrate CodeDigger

**Code:**
- ✅ graph.py - 31 methods for all node/relationship operations
- ✅ graph_schema.py - 6 node type definitions
- ✅ graph_queries.py - 18 analytics queries
- ✅ tests/test_graph_schema_integration.py - 21 comprehensive tests
- ✅ models.py - Updated with 6 dataclasses

**Test Results:**
- ✅ 78/78 tests passing (57 existing + 21 new)

---

## What We're NOT Changing

- ConfigManager and hardcoded IP (can wait for production thinking)
- Model versions (claude-haiku-4-5 update is trivial)
- Documentation cleanup (Phase 4)

---

## Final Decision Point

**What should we start with?**

```
A) Migrations → CodeDigger → Firewall → Dogfooding
   (RECOMMENDED - solid foundation first)

B) CodeDigger → Migrations → Firewall → Dogfooding
   (Fast visible value, then foundation)

C) Firewall → Migrations → CodeDigger → Dogfooding
   (Spec compliance first)

D) Something else?
```

Давай я жду твого выбора и раз выбрал - сразу начинаем?

---

## Work Estimate

**Option A (Recommended):**
- Week 1: 2-3 days migration setup + CodeDigger client
- Week 1-2: 3-4 days CodeDigger integration (detection + hook)
- Week 2-3: 2-3 days Anti-Bias Firewall
- Week 3-4: 3-5 days Dogfooding + validation

**Total:** 10-15 developer days over 4 weeks

---

## What Happens Next

Once you choose direction, I will:

1. Create detailed implementation tasks
2. Start building Phase 0.1
3. Keep you updated with progress
4. Handle blockers immediately
5. Maintain test coverage (no regressions)

🚀 Ready when you are!
