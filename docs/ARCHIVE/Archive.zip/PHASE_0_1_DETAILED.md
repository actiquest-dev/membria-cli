# Phase 0.1: Migrations - Detailed Implementation Plan

**Duration:** 3-4 days
**Goal:** Schema versioning + auto-migrate on startup
**Status:** Ready to implement

---

## Files to Create/Modify

```
NEW FILES:
  src/membria/migrations/
    ├─ __init__.py
    ├─ migrator.py              (Migration runner)
    ├─ base.py                  (Migration base class)
    └─ versions/
        ├─ __init__.py
        ├─ v0_1_0_initial.py     (Initial Decision nodes)
        └─ v0_2_0_engrams.py     (Add Engram nodes + MADE_IN)

  src/membria/commands/
    └─ db.py                    (NEW: db command group)

  tests/
    ├─ test_migrations.py        (Migration tests)
    └─ test_version_management.py (Version tracking tests)

MODIFY FILES:
  src/membria/__init__.py         (Add __version__)
  src/membria/cli.py              (Auto-migrate on startup)
  src/membria/graph.py            (Add migration methods)
  src/membria/models.py           (Add migration models)
```

---

## 1. Migration Base Class (src/membria/migrations/base.py)

```python
from abc import ABC, abstractmethod
from typing import Any, Dict
from datetime import datetime
from membria.graph import GraphClient

class Migration(ABC):
    """Base class for all migrations"""

    VERSION: str  # e.g., "0.1.0"
    DESCRIPTION: str
    DEPENDENCIES: list = []  # e.g., ["v0_1_0_initial"]

    def __init__(self, graph: GraphClient):
        self.graph = graph
        self.timestamp = int(datetime.now().timestamp())

    @abstractmethod
    def migrate(self) -> bool:
        """Apply migration (upgrade)"""
        pass

    @abstractmethod
    def rollback(self) -> bool:
        """Rollback migration (downgrade)"""
        pass

    @abstractmethod
    def validate(self) -> bool:
        """Validate migration success"""
        pass

    def log(self, message: str):
        """Log migration progress"""
        print(f"[{self.VERSION}] {message}")
```

---

## 2. Migration v0.1.0: Initial Schema (src/membria/migrations/versions/v0_1_0_initial.py)

```python
from membria.migrations.base import Migration

class V0_1_0_Initial(Migration):
    """Initial schema - Decision nodes only"""

    VERSION = "0.1.0"
    DESCRIPTION = "Initial Decision nodes"
    DEPENDENCIES = []

    def migrate(self) -> bool:
        """Create initial schema"""
        try:
            self.log("Creating Decision node type...")

            # Create Decision nodes structure (already exists in schema)
            # Just validate it's there
            result = self.graph.query(
                "MATCH (d:Decision) RETURN count(d) as cnt"
            )
            self.log(f"Decision nodes found: {result[0]['cnt']}")

            # Create indices for performance
            self.log("Creating indices...")
            indices = [
                "CREATE INDEX ON :Decision(id)",
                "CREATE INDEX ON :Decision(module)",
                "CREATE INDEX ON :Decision(created_at)",
            ]

            for idx_query in indices:
                try:
                    self.graph.query(idx_query)
                    self.log(f"Index created: {idx_query}")
                except Exception as e:
                    # Index might already exist
                    if "already exists" not in str(e):
                        raise

            # Record this migration in graph
            self.log("Recording migration...")
            self.graph.query(f"""
                CREATE (:Migration {{
                    id: "v0_1_0_initial",
                    version_from: "0.0.0",
                    version_to: "0.1.0",
                    timestamp: {self.timestamp},
                    status: "completed",
                    description: "{self.DESCRIPTION}"
                }})
            """)

            # Create SchemaVersion node
            self.log("Recording schema version...")
            self.graph.query(f"""
                CREATE (:SchemaVersion {{
                    version: "0.1.0",
                    cli_version: "0.1.0",
                    timestamp: {self.timestamp},
                    migration_count: 1,
                    notes: "Initial Decision nodes"
                }})
            """)

            self.log("✅ Migration v0.1.0 complete")
            return True

        except Exception as e:
            self.log(f"❌ Migration failed: {e}")
            return False

    def rollback(self) -> bool:
        """Rollback v0.1.0"""
        try:
            self.log("Rolling back v0.1.0...")

            # Remove indices
            self.log("Removing indices...")
            indices = [
                "DROP INDEX ON :Decision(id)",
                "DROP INDEX ON :Decision(module)",
                "DROP INDEX ON :Decision(created_at)",
            ]

            for idx_query in indices:
                try:
                    self.graph.query(idx_query)
                except:
                    pass  # Index might not exist

            # Remove migration record
            self.graph.query("""
                MATCH (m:Migration {id: "v0_1_0_initial"})
                DELETE m
            """)

            # Remove schema version
            self.graph.query("""
                MATCH (sv:SchemaVersion {version: "0.1.0"})
                DELETE sv
            """)

            self.log("✅ Rollback complete")
            return True

        except Exception as e:
            self.log(f"❌ Rollback failed: {e}")
            return False

    def validate(self) -> bool:
        """Validate migration succeeded"""
        try:
            # Check Decision nodes still work
            result = self.graph.query("MATCH (d:Decision) RETURN count(d)")
            self.log(f"✅ Validation passed - {result[0]['count']} Decision nodes")
            return True
        except Exception as e:
            self.log(f"❌ Validation failed: {e}")
            return False
```

---

## 3. Migration v0.2.0: Add Engram Nodes (src/membria/migrations/versions/v0_2_0_engrams.py)

```python
from membria.migrations.base import Migration

class V0_2_0_Engrams(Migration):
    """Add Engram nodes and MADE_IN relationship"""

    VERSION = "0.2.0"
    DESCRIPTION = "Add Engram nodes and MADE_IN relationship"
    DEPENDENCIES = ["v0_1_0_initial"]

    def migrate(self) -> bool:
        """Add Engram schema"""
        try:
            self.log("Creating Engram node type...")

            # Create indices for Engram
            self.log("Creating Engram indices...")
            indices = [
                "CREATE INDEX ON :Engram(id)",
                "CREATE INDEX ON :Engram(session_id)",
                "CREATE INDEX ON :Engram(created_at)",
            ]

            for idx_query in indices:
                try:
                    self.graph.query(idx_query)
                    self.log(f"Index created: {idx_query}")
                except Exception as e:
                    if "already exists" not in str(e):
                        raise

            # Verify existing Decision nodes still work
            result = self.graph.query(
                "MATCH (d:Decision) RETURN count(d) as cnt"
            )
            self.log(f"Existing Decision nodes: {result[0]['cnt']}")

            # Record migration
            self.log("Recording migration...")
            self.graph.query(f"""
                CREATE (:Migration {{
                    id: "v0_2_0_engrams",
                    version_from: "0.1.0",
                    version_to: "0.2.0",
                    timestamp: {self.timestamp},
                    status: "completed",
                    description: "{self.DESCRIPTION}"
                }})
            """)

            # Update SchemaVersion
            self.log("Updating schema version...")
            self.graph.query(f"""
                MATCH (sv:SchemaVersion {{version: "0.1.0"}})
                SET sv.version = "0.2.0",
                    sv.timestamp = {self.timestamp},
                    sv.migration_count = 2,
                    sv.notes = "Added Engram nodes and MADE_IN relationship"
            """)

            self.log("✅ Migration v0.2.0 complete")
            return True

        except Exception as e:
            self.log(f"❌ Migration failed: {e}")
            return False

    def rollback(self) -> bool:
        """Rollback v0.2.0"""
        try:
            self.log("Rolling back v0.2.0...")

            # Remove Engram indices
            indices = [
                "DROP INDEX ON :Engram(id)",
                "DROP INDEX ON :Engram(session_id)",
                "DROP INDEX ON :Engram(created_at)",
            ]

            for idx_query in indices:
                try:
                    self.graph.query(idx_query)
                except:
                    pass

            # Remove MADE_IN relationships
            self.graph.query("""
                MATCH (d:Decision)-[r:MADE_IN]->(e:Engram)
                DELETE r
            """)

            # Remove Engram nodes
            self.graph.query("MATCH (e:Engram) DELETE e")

            # Remove migration record
            self.graph.query("""
                MATCH (m:Migration {id: "v0_2_0_engrams"})
                DELETE m
            """)

            # Revert SchemaVersion
            self.graph.query(f"""
                MATCH (sv:SchemaVersion {{version: "0.2.0"}})
                SET sv.version = "0.1.0",
                    sv.migration_count = 1
            """)

            self.log("✅ Rollback complete")
            return True

        except Exception as e:
            self.log(f"❌ Rollback failed: {e}")
            return False

    def validate(self) -> bool:
        """Validate migration succeeded"""
        try:
            # Check Engram nodes can be created
            result = self.graph.query("MATCH (e:Engram) RETURN count(e)")
            # Check Decision nodes still work
            result2 = self.graph.query("MATCH (d:Decision) RETURN count(d)")
            self.log(f"✅ Validation passed - Engram nodes: {result[0]['count']}, Decision nodes: {result2[0]['count']}")
            return True
        except Exception as e:
            self.log(f"❌ Validation failed: {e}")
            return False
```

---

## 4. Migration Runner (src/membria/migrations/migrator.py)

```python
import importlib
import logging
from typing import List, Optional
from membria.graph import GraphClient
from membria.migrations.base import Migration

logger = logging.getLogger(__name__)

class Migrator:
    """Run migrations in sequence"""

    MIGRATION_VERSIONS = [
        "v0_1_0_initial",
        "v0_2_0_engrams",
    ]

    def __init__(self, graph: GraphClient):
        self.graph = graph
        self.current_version = self._get_current_version()

    def _get_current_version(self) -> str:
        """Get schema version from graph"""
        try:
            result = self.graph.query(
                "MATCH (sv:SchemaVersion) "
                "RETURN sv.version "
                "ORDER BY sv.timestamp DESC LIMIT 1"
            )
            return result[0]['version'] if result else "0.0.0"
        except:
            return "0.0.0"

    def _load_migration(self, version: str) -> Migration:
        """Dynamically load migration class"""
        # Convert v0_1_0_initial → v0_1_0_initial.V0_1_0_Initial
        module_name = version
        class_name = "".join(
            word.capitalize() for word in version.split("_")
        )

        module = importlib.import_module(
            f"membria.migrations.versions.{module_name}"
        )
        migration_class = getattr(module, class_name)
        return migration_class(self.graph)

    def migrate_to(self, target_version: str) -> bool:
        """Migrate from current to target version"""
        print(f"\n📦 Migrating from {self.current_version} to {target_version}...")

        # Find migrations to apply
        migrations_to_apply = []
        for version in self.MIGRATION_VERSIONS:
            # Extract version number (0.1.0 from v0_1_0_initial)
            version_num = version.split("_")[0] + "." + version.split("_")[1] + "." + version.split("_")[2]

            if version_num > self.current_version and version_num <= target_version:
                migrations_to_apply.append(version)

        if not migrations_to_apply:
            print("✅ Already at target version")
            return True

        # Apply each migration
        for version in migrations_to_apply:
            print(f"\n  Running {version}...")
            migration = self._load_migration(version)

            # Run migration
            if not migration.migrate():
                print(f"  ❌ Migration failed!")
                return False

            # Validate
            if not migration.validate():
                print(f"  ❌ Validation failed!")
                if not migration.rollback():
                    print(f"  ⚠️  Rollback also failed!")
                return False

            print(f"  ✅ {version} complete")
            self.current_version = version.split("_")[0] + "." + version.split("_")[1] + "." + version.split("_")[2]

        print(f"\n✅ Migration complete! Now at {self.current_version}")
        return True

    def rollback_to(self, target_version: str) -> bool:
        """Rollback from current to target version"""
        print(f"\n⚠️  Rolling back from {self.current_version} to {target_version}...")

        # Find migrations to rollback (in reverse order)
        migrations_to_rollback = []
        for version in reversed(self.MIGRATION_VERSIONS):
            version_num = version.split("_")[0] + "." + version.split("_")[1] + "." + version.split("_")[2]

            if version_num > target_version and version_num <= self.current_version:
                migrations_to_rollback.append(version)

        if not migrations_to_rollback:
            print("✅ Already at target version")
            return True

        # Rollback each migration
        for version in migrations_to_rollback:
            print(f"\n  Rolling back {version}...")
            migration = self._load_migration(version)

            if not migration.rollback():
                print(f"  ❌ Rollback failed!")
                return False

            print(f"  ✅ {version} rolled back")

        print(f"\n✅ Rollback complete! Now at {target_version}")
        return True
```

---

## 5. CLI Commands (src/membria/commands/db.py)

```python
import typer
from rich.console import Console
from membria.config import ConfigManager
from membria.graph import GraphClient
from membria.migrations.migrator import Migrator
from membria import __version__

console = Console()
db_app = typer.Typer(help="Database and schema management")

@db_app.command("version")
def version():
    """Show schema and CLI versions"""
    config = ConfigManager()
    graph = GraphClient(config.get_falkordb_config())

    if not graph.connect():
        console.print("[red]✗[/red] Cannot connect to FalkorDB")
        raise typer.Exit(code=1)

    migrator = Migrator(graph)
    current = migrator.current_version
    cli_ver = __version__

    console.print(f"[cyan]Schema version:[/cyan] {current}")
    console.print(f"[cyan]CLI version:   [/cyan] {cli_ver}")

    if current != cli_ver:
        console.print(f"[yellow]⚠️  Mismatch![/yellow] Run: membria db migrate")

    graph.disconnect()

@db_app.command("migrate")
def migrate(to: str = typer.Option(None, "--to", help="Target version")):
    """Migrate schema to target version"""
    config = ConfigManager()
    graph = GraphClient(config.get_falkordb_config())

    if not graph.connect():
        console.print("[red]✗[/red] Cannot connect to FalkorDB")
        raise typer.Exit(code=1)

    migrator = Migrator(graph)
    target = to or __version__

    if migrator.migrate_to(target):
        console.print(f"[green]✅ Migration complete![/green]")
    else:
        console.print(f"[red]❌ Migration failed![/red]")
        raise typer.Exit(code=1)

    graph.disconnect()

@db_app.command("rollback")
def rollback(to: str = typer.Option(..., "--to", help="Target version")):
    """Rollback schema to previous version"""
    config = ConfigManager()
    graph = GraphClient(config.get_falkordb_config())

    if not graph.connect():
        console.print("[red]✗[/red] Cannot connect to FalkorDB")
        raise typer.Exit(code=1)

    confirm = console.input(
        f"[yellow]⚠️  Rollback to {to}? [y/N]:[/yellow] "
    )

    if confirm.lower() != "y":
        console.print("Cancelled")
        raise typer.Exit()

    migrator = Migrator(graph)

    if migrator.rollback_to(to):
        console.print(f"[green]✅ Rollback complete![/green]")
    else:
        console.print(f"[red]❌ Rollback failed![/red]")
        raise typer.Exit(code=1)

    graph.disconnect()
```

---

## 6. Auto-Migrate on Startup (Modify src/membria/cli.py)

```python
# At the top of main() or init():

from membria import __version__
from membria.migrations.migrator import Migrator

def main():
    """CLI entry point"""

    # Initialize
    config = ConfigManager()
    graph = GraphClient(config.get_falkordb_config())

    if not graph.connect():
        console.print("[red]✗[/red] Cannot connect to FalkorDB")
        raise typer.Exit(code=1)

    # AUTO-MIGRATE ON STARTUP
    migrator = Migrator(graph)
    schema_version = migrator.current_version
    cli_version = __version__

    if schema_version != cli_version:
        console.print(f"[yellow]📦 Schema version mismatch![/yellow]")
        console.print(f"  Schema: {schema_version}")
        console.print(f"  CLI:    {cli_version}")
        console.print(f"[cyan]Migrating...[/cyan]")

        if not migrator.migrate_to(cli_version):
            console.print("[red]❌ Migration failed![/red]")
            console.print("Run: membria db rollback --to {schema_version}")
            raise typer.Exit(code=1)

        console.print("[green]✅ Migration complete![/green]")

    # Continue with normal CLI flow
    graph.disconnect()
    ...
```

---

## 7. Update __init__.py (src/membria/__init__.py)

```python
"""Membria CLI - Decision-aware development companion"""

__version__ = "0.1.0"
__author__ = "Anthropic"

# ... rest of imports ...
```

---

## 8. Tests (tests/test_migrations.py)

```python
import pytest
from membria.migrations.migrator import Migrator
from membria.migrations.versions.v0_1_0_initial import V0_1_0_Initial
from membria.migrations.versions.v0_2_0_engrams import V0_2_0_Engrams
from membria.graph import GraphClient


@pytest.fixture
def mock_graph(mocker):
    """Mock GraphClient"""
    mock = mocker.MagicMock(spec=GraphClient)
    mock.query.return_value = [{"count": 0, "cnt": 0, "version": "0.1.0"}]
    return mock


def test_migration_v0_1_0_initial(mock_graph):
    """Test v0.1.0 migration"""
    migration = V0_1_0_Initial(mock_graph)
    assert migration.VERSION == "0.1.0"
    assert migration.migrate() is True
    assert migration.validate() is True


def test_migration_v0_2_0_engrams(mock_graph):
    """Test v0.2.0 migration"""
    migration = V0_2_0_Engrams(mock_graph)
    assert migration.VERSION == "0.2.0"
    assert migration.migrate() is True
    assert migration.validate() is True


def test_migrator_get_current_version(mock_graph):
    """Test version detection"""
    migrator = Migrator(mock_graph)
    assert migrator.current_version in ["0.0.0", "0.1.0"]


def test_rollback(mock_graph):
    """Test rollback functionality"""
    migration = V0_1_0_Initial(mock_graph)
    assert migration.rollback() is True
```

---

## Task Breakdown (by Day)

**Day 1:**
- [ ] Create migration base class (base.py)
- [ ] Create v0.1.0 initial migration
- [ ] Create v0.2.0 engrams migration
- [ ] Write tests for migrations

**Day 2:**
- [ ] Create migrator.py (runner)
- [ ] Create db.py CLI commands
- [ ] Integration tests
- [ ] Test rollback functionality

**Day 3:**
- [ ] Add auto-migrate to cli.py startup
- [ ] Add __version__ to __init__.py
- [ ] End-to-end tests
- [ ] Manual testing with FalkorDB

**Day 4 (Polish):**
- [ ] Edge case handling
- [ ] Error messages improvement
- [ ] Documentation
- [ ] Final testing

---

## Success Criteria

✅ All Phase 0.1 tests passing (>20 new tests)
✅ No regressions (78 existing tests still pass)
✅ Auto-migrate works on startup
✅ Rollback works correctly
✅ CLI commands work: version, migrate, rollback
✅ Schema version tracked in Graph
✅ Migration history stored

---

**Ready to start coding?** 🚀

Start with: `src/membria/migrations/base.py`
