# Phase 0: Single-User MVP (3-4 weeks)

**Constraint:** One developer, one project
**Goal:** Personal decision recording + pre-commit prevention + learn from own outcomes

---

## What We DON'T Need (Single-User)

❌ Multi-tenant RBAC (only 1 user)
❌ Team calibration profiles (no team)
❌ Team lead notifications (no team)
❌ Ensemble disagreement (1 model = Claude)
❌ Shared decision history (individual use)
❌ Causal discovery agent (advanced)
❌ IDE extensions (too complex for MVP)
❌ Multiple event sources (GitHub webhooks, Jira, PagerDuty)

**Simplified to:**
✅ Personal decision recording
✅ Personal calibration ("Am I overconfident?")
✅ Pre-commit antipattern prevention (CodeDigger evidence)
✅ Basic context injection to Claude Code
✅ Manual outcome recording

---

## Phase 0 for Single-User

### 0.1: Migrations (3-4 days)
**Why:** Safe schema updates, versioning

```
NEW:
  src/membria/migrations/
    ├─ migrator.py
    └─ versions/
        ├─ v0_1_0_initial.py
        └─ v0_2_0_engrams.py

MODIFY:
  src/membria/__init__.py (version tracking)
  src/membria/cli.py (auto-migrate on startup)
```

**Key files:**
- Migration runner (run pending migrations)
- Version checking (on startup)
- Rollback capability
- Store migration history in Graph

**CLI:**
```bash
membria version                 # Show current schema version
membria db migrate             # Auto-migrate to CLI version
membria db rollback --to 0.1.0 # Rollback if needed
```

---

### 0.2: CodeDigger Integration (3-4 days)
**Why:** Pre-commit prevention (most visible value)

```
NEW:
  src/membria/codedigger_client.py      # API client + caching
  src/membria/pattern_matcher.py        # Stage 1-3 detection
  src/membria/commands/antipattern.py   # CLI commands
  src/membria/hooks/pre-commit          # Git hook
  tests/test_codedigger_integration.py

MODIFY:
  src/membria/models.py (add pattern detection fields)
  src/membria/graph.py (store antipattern findings)
```

**Implementation:**

**1. CodeDigger Client** (fetch + cache patterns)
```python
class CodeDiggerClient:
    """Consume CodeDigger API"""

    async def get_patterns(self) -> List[Pattern]:
        """GET /api/patterns - fetch all 25 patterns"""
        # Cache for 24 hours in memory
        # Pattern: id, name, removal_rate, severity, keywords, regex_pattern

    async def get_occurrences(self, pattern_id: str) -> List[Occurrence]:
        """GET /api/occurrences - fetch examples from GitHub"""
        # Show: file_path, repo, confidence, match_text
        # Used for evidence display

    async def health_check(self) -> bool:
        """GET /health - is CodeDigger alive?"""
```

**2. Pattern Matcher** (Stage 1-3 logic only, NO LLM)
```python
class PatternMatcher:
    """Match patterns in git diff"""

    def match_in_diff(self, diff: str) -> List[DetectionResult]:
        """Find patterns in staged code"""
        # Stage 1: Regex matching (from CodeDigger patterns)
        # Stage 2: Simple syntax checks
        # Stage 3: Import validation
        # Confidence: 0.75-0.85 (no LLM)
```

**3. Pre-Commit Hook**
```bash
#!/bin/bash
# .git/hooks/pre-commit

membria antipattern-check --staged

# Exit codes:
#   0 = OK, commit allowed
#   1 = WARNING, can override with --force
#   2 = BLOCKED, prevent commit
```

**4. Evidence Display**
```
⚠️  ANTIPATTERN DETECTED: Custom JWT

📊 EVIDENCE:
├─ Industry: 89% removed (20,470 repos)
├─ Avg removal: 97 days
├─ Examples: [links to GitHub examples]
└─ Your team: First time trying this

💡 Recommendation: Use passport-jwt instead

Override? membria commit --force
```

**CLI:**
```bash
membria antipattern-check --staged          # Check staged changes
membria antipattern-evidence custom_jwt     # Show evidence
membria antipattern-examples custom_jwt     # Show GitHub examples
membria commit --force --reason "special"   # Override if needed
```

**Tests:**
```python
def test_fetch_patterns_from_codedigger():
def test_cache_patterns_24_hours():
def test_detect_custom_jwt_in_diff():
def test_pre_commit_hook_blocks_critical():
def test_evidence_formatting():
```

---

### 0.3: Anti-Bias Firewall (Basic Version) (3-4 days)
**Why:** Block obviously bad decisions before they happen

```
NEW:
  src/membria/firewall.py               # Decision blocking
  src/membria/red_flags.py              # Simple signal detection
  src/membria/commands/firewall.py      # CLI
  tests/test_firewall.py

MODIFY:
  src/membria/models.py (add firewall fields)
  src/membria/graph.py (store firewall decisions)
```

**Simple Version (NOT full Phase 3 spec):**

**1. Red Flag Detector** (only 2-3 signals for MVP)
```python
class RedFlagDetector:
    """Detect obvious risks in decisions"""

    def detect_flags(self, decision: Decision) -> List[str]:
        """Returns flags like: ["low_confidence", "no_alternatives"]"""

        flags = []

        # Flag 1: Confidence too low
        if decision.confidence < 0.5:
            flags.append("low_confidence")

        # Flag 2: No alternatives considered
        if not decision.alternatives or len(decision.alternatives) < 2:
            flags.append("no_alternatives")

        # Flag 3: Antipattern detected in statement
        if self._is_risky_pattern(decision.statement):
            flags.append("known_antipattern")

        return flags
```

**2. Simple Firewall Logic**
```python
class Firewall:
    """Block obviously bad decisions"""

    def should_block(self, decision: Decision, flags: List[str]) -> bool:
        """True = block decision, ask for confirmation"""

        # Block if:
        # - Confidence < 0.5 AND no alternatives
        # - Known antipattern (89%+ removal rate)
        # - 2+ red flags

        if len(flags) >= 2:
            return True

        if "known_antipattern" in flags:
            return True

        return False
```

**3. CLI Interface**
```bash
membria safety analyze "Use custom JWT for auth"
# → Detects antipattern
# → Shows: 89% removal rate
# → Firewall: BLOCK

membria safety override --reason "special case"
# → Allows it but logs the override
```

**Tests:**
```python
def test_detect_low_confidence():
def test_detect_no_alternatives():
def test_firewall_blocks_antipatterns():
def test_firewall_shows_evidence():
```

---

## Phase 0 Summary: What Works at End

```
Developer workflow:

1. Write code
   → Git add .

2. Try to commit
   → Pre-commit hook runs

3. Membria checks:
   ✅ CodeDigger patterns (89% custom JWT failure)
   ✅ Firewall flags (low confidence? no alternatives?)
   ✅ Decision quality

4. Results:
   ✅ PROCEED (safe)
   ⚠️  WARN (risky, can --force)
   🚫 BLOCK (critical, must override)

5. Commit succeeds
   → Decision NOT recorded yet
      (That's Phase 1)
```

---

## Single-User Simplifications

### Compared to Multi-User:

| Feature | Multi-User | Single-User |
|---------|-----------|------------|
| RBAC | Full policy engine | None (1 user) |
| Team calibration | Per-domain, per-team | Single profile |
| Notifications | Team lead alerts | Silent (just log) |
| Event sources | GitHub, CI, Jira, Time | Manual only |
| Decision Surface | IDE panel + CLI | CLI only |
| MCP injection | Full context system | Simple CLI context |
| Outcome capture | Automated webhooks | `membria outcome record` |

### What We Skip:

1. ❌ IDE extension (too much work for MVP)
2. ❌ GitHub webhooks (manual tracking is OK for 1 user)
3. ❌ Multi-agent consensus (only 1 Claude anyway)
4. ❌ Team calibration profiles (1 person = 1 profile)
5. ❌ Causal discovery (advanced, can wait)

---

## No Blocker Dependencies

All Phase 0 tasks are **independent**:
- 0.1 Migrations doesn't block 0.2 or 0.3
- 0.2 CodeDigger doesn't block 0.1 or 0.3
- 0.3 Firewall doesn't block 0.1 or 0.2

**Can run in parallel!**

```
Week 1:
├─ Task 0.1a: Migration framework (1 day)
├─ Task 0.2a: CodeDigger client (1 day)
├─ Task 0.3a: Red flag detector (1 day)
└─ Integration tests (1 day)

Week 1-2:
├─ Task 0.1b: Auto-migrate on startup (0.5 days)
├─ Task 0.2b: Pattern matching + hook (1.5 days)
├─ Task 0.3b: Firewall logic (1 day)
└─ E2E tests (1 day)

Week 2:
├─ Task 0.1c: Test migrations (0.5 days)
├─ Task 0.2c: Evidence formatting (0.5 days)
├─ Task 0.3c: CLI commands (0.5 days)
└─ Final testing (1.5 days)
```

**Total: 10-12 days of work (2-2.5 weeks)**

---

## Success Criteria (Phase 0 Complete)

```
✅ Migrations work (can version schema)
✅ CodeDigger API accessible
✅ Patterns cached locally
✅ Pre-commit hook detects antipatterns
✅ Evidence displays removal rates
✅ Can override with --force
✅ Firewall blocks obvious risks
✅ All Phase 0 tests passing (>25 new tests)
✅ No regressions (78 existing tests still pass)
✅ Ready for Phase 1 (decision recording)
```

---

## Next Step

**Should we:**

1. **Start Phase 0 immediately** with detailed task breakdown?
2. **Plan Phase 1 first** (decision recording for single user)?
3. **Something else?**

🚀 Ready to go?
