# CodeDigger Integration Plan for Membria CLI

**Status:** READY FOR IMPLEMENTATION
**API Server:** codedigger.membria.ai:4000
**Backend:** membria-cli/backend/ (running on GCP VM)

---

## What CodeDigger Does

Backend service that:
1. **Crawls GitHub** - 965+ repositories, 155,933 commits
2. **Detects 25 Antipatterns** - 4-stage pipeline (Regex → AST → Context → LLM)
3. **Collects Statistics** - 7,761+ patterns detected, removal rates, timelines
4. **Provides REST API (Port 4000):**
   - `GET /api/patterns` - All 25 pattern definitions
   - `GET /api/stats` - Global statistics (repos, commits, occurrences)
   - `GET /api/occurrences` - Detected instances with examples
   - `GET /api/repos` - Repository metrics
   - `GET /api/services` - Pipeline status (crawler, worker, diff-loader)
   - `POST /api/mine` - Trigger mining for specific repo
   - `POST /api/chat` - RAG chat with GLM-4-plus
   - `GET /health` - Health check

**Detection Pipeline:**
- **Stage 1:** Regex filter (keywords: jwt.sign, eval, etc)
- **Stage 2:** AST analysis (Acorn parser)
- **Stage 3:** Context validator (check imports)
- **Stage 4:** LLM validation (GLM-4.6, cached 30 days in Redis)

---

## The 25 Antipatterns CodeDigger Detects

**Critical (Blocking):**
1. Hardcoded secrets (API keys, SSH keys)
2. TLS/SSL verification disabled
3. Unsafe exec/eval (command injection)
4. Custom crypto/JWT (89% removal rate!)

**High (Warn):**
5. Empty catch/except
6. Silent fallback (swallowed errors)
7. Async forEach (no await)
8. Floating promise (unhandled)
9. Tests skipped/disabled
10. Fix without tests
11. N+1 queries
12. Sync blocking IO in handlers
13. Global cache without TTL

**Medium (Alert):**
14. Lint suppression (eslint-disable, @ts-ignore)
15. Magic timeouts (hardcoded ms values)
16. Guard clause explosion
17. Complexity spike
18. Commented-out code
19. Copy-paste duplication
20. Generic naming (Manager, Handler, Util)
21. Overly broad exception handlers
22. Missing validation/sanitization
23. Deprecated API usage
24. Performance anti-patterns
25. Inconsistent error handling

---

## Integration Flow

```
Developer writes code
        ↓
Pre-commit hook runs
        ↓
Membria CLI:
  1. Get staged diff (git diff --cached)
  2. Load patterns from CodeDigger API (cached locally)
     - Query: GET https://codedigger.membria.ai:4000/api/patterns
     - Cache in memory for 24 hours
  3. Match patterns against diff using Stage 1-3 logic:
     - Stage 1: Regex matching (keywords from CodeDigger)
     - Stage 2: Simple AST checks (if available)
     - Stage 3: Import context validation
     (Note: NOT running Stage 4 LLM - CodeDigger already does this)
  4. Query local FalkorDB graph for team history:
     - Have we tried this pattern before?
     - Did it get reworked/removed?
     - What was the outcome?
  5. Fetch evidence from CodeDigger:
     - GET /api/occurrences?pattern_id=custom_jwt
     - removal_rate: 89% (from 20,470 repos)
     - avg_days_to_removal: 97 days
     - examples: Show 2-3 concrete cases
  6. Show compiled evidence to developer:
     ├─ "Custom JWT: 89% removed (20,470 repos)"
     ├─ "Avg removal time: 97 days"
     ├─ "Your team tried this 2x"
     ├─ "Last attempt: removed 14 days ago"
     ├─ "Common replacements: passport-jwt, express-jwt"
     └─ Decision Firewall: BLOCK or WARN or ALLOW
        ↓
Developer sees:
  ✅ PROCEED (safe or unknown pattern)
  ⚠️  WARN (risky, removal_rate 50-80%, can override)
  🚫 BLOCK (critical, removal_rate > 80%, needs team lead)
```

**Key Distinction:**
- CodeDigger: Analyzes 965 GitHub repos, provides statistics & examples
- Membria CLI: Consumes CodeDigger stats, adds personal team history, enforces firewall

---

## What We Need to Build

### Phase 0.1: CodeDigger Client & Pattern Detection
**Time: 2-3 days**
**Location:** `src/membria/` (CLI side)

We're consuming an external API, not building detection from scratch!

1. **CodeDigger Client** (`src/membria/codedigger_client.py`)
   ```python
   class CodeDiggerClient:
       def __init__(self, base_url: str = "https://codedigger.membria.ai:4000"):
           self.base_url = base_url
           self.patterns_cache = {}
           self.cache_ttl = 86400  # 24 hours

       async def get_patterns(self) -> List[Pattern]:
           """Fetch all 25 patterns from CodeDigger"""
           # GET /api/patterns
           # Cache in memory for 24 hours
           # Returns: id, name, severity, removal_rate, repos_affected,
           #          keywords, regex_pattern, recommendation

       async def get_stats(self) -> Dict:
           """Get global statistics"""
           # GET /api/stats
           # Returns: repos count, commits processed, occurrences found

       async def get_occurrences(self, pattern_id: str, limit: int = 5) -> List[Occurrence]:
           """Get concrete examples from open source repos"""
           # GET /api/occurrences?pattern_id=custom_jwt&limit=5
           # Returns: file_path, line_number, confidence, match_text, repo name

       async def get_services_status(self) -> Dict:
           """Check if CodeDigger pipeline is healthy"""
           # GET /api/services
           # Returns: status of miner, worker, diff-loaders
   ```

2. **Pattern Matcher** (`src/membria/pattern_matcher.py`)
   ```python
   class PatternMatcher:
       """Match staged code against CodeDigger patterns (Stage 1-3 only)"""

       def __init__(self, codedigger_client: CodeDiggerClient, graph_client: GraphClient):
           self.patterns = codedigger_client.patterns_cache
           self.graph = graph_client

       def match_in_diff(self, diff: str) -> List[DetectionResult]:
           """Find patterns in git diff using Stage 1-3 logic"""
           results = []
           for pattern in self.patterns:
               # Stage 1: Regex matching
               if self._regex_match(diff, pattern['regex_pattern']):
                   # Stage 2: Simple AST validation (if language supported)
                   if self._ast_validate(diff, pattern):
                       # Stage 3: Context validation (check imports)
                       if self._context_validate(diff, pattern):
                           result = DetectionResult(
                               pattern_id=pattern['id'],
                               pattern_name=pattern['name'],
                               severity=pattern['severity'],
                               removal_rate=pattern['removal_rate'],
                               confidence=0.85  # No LLM, so lower confidence
                           )
                           results.append(result)
           return results

       def get_team_history(self, pattern_id: str) -> Dict:
           """Query graph for team's past experience with this pattern"""
           # MATCH (d:Decision)-[:USED_ANTIPATTERN]->(ap:AntiPattern {id: pattern_id})
           # Return: count tried, count removed, last attempt date, outcomes
   ```

3. **Evidence Aggregator** (`src/membria/evidence_aggregator.py`)
   ```python
   class EvidenceAggregator:
       """Combine CodeDigger stats + team history"""

       async def aggregate(self, detection: DetectionResult) -> Evidence:
           """Compile evidence from multiple sources"""
           return Evidence(
               # From CodeDigger API
               industry_removal_rate=detection.removal_rate,
               industry_repos=detection.repos_affected,
               avg_days_to_removal=detection.avg_days_to_removal,
               examples=await self.codedigger.get_occurrences(detection.pattern_id),

               # From local Graph
               team_tried_count=team_history['count'],
               team_removed_count=team_history['removed'],
               last_attempt=team_history['last_date'],

               recommendation=detection.recommendation
           )

       def format_for_display(self, evidence: Evidence) -> str:
           """Pretty print evidence for terminal"""
   ```

4. **Pre-Commit Hook** (`src/membria/hooks/pre-commit`)
   ```bash
   #!/bin/bash
   # .git/hooks/pre-commit
   # Called automatically when developer tries to commit

   membria antipattern-check --staged
   # Returns:
   #   ✅ 0 = all clear, commit allowed
   #   ⚠️  1 = warning, prompt user (can override with --force)
   #   🚫  2 = blocked, prevent commit (critical antipattern)
   ```

**Note:** We're NOT implementing Stage 4 (LLM validation) - CodeDigger already does that!

### Phase 0.2: Decision Firewall
**Time: 2-3 days**
**Builds on Phase 0.1**

Implement AntiBiasFirewall from BIAS_DEFENSE_GAP_ANALYSIS.md:
- Red flag detection (5 signals)
- Escalation matrix (Low → Critical)
- Blocking mechanism
- Team lead notification

### Phase 0.3: Migration System
**Time: 2-3 days**
**Parallel with above**

From VERSIONING_STRATEGY.md:
- Migration runner
- v0.1.0 initial schema
- v0.2.0 add Engram nodes
- Auto-migrate on startup

---

## API Endpoints We'll Consume

**CodeDigger is running at:** `https://codedigger.membria.ai:4000`

### 1. GET /api/patterns
Returns all 25 pattern definitions from `config/patterns.yaml`
```json
{
  "patterns": [
    {
      "id": "custom_jwt",
      "name": "Custom JWT Implementation",
      "severity": "high",
      "removal_rate": 0.89,
      "repos_affected": 20470,
      "avg_days_to_removal": 97,
      "keywords": ["custom", "jwt", "sign", "verify"],
      "regex_pattern": "(?:jwt\\.sign|crypto\\.sign)\\(",
      "recommendation": "Use passport-jwt instead",
      "evidence": "89% removed within 97 days"
    },
    ...
  ]
}
```

### 2. GET /api/stats
```json
{
  "repos": 965,
  "commits_total": 155933,
  "commits_processed": 155933,
  "occurrences": 7761,
  "diffs_loaded": 17000,
  "diffs_pending": 138000,
  "by_pattern": [
    {"pattern_id": "custom_jwt", "action": "added", "count": 2847},
    {"pattern_id": "async_forEach", "action": "added", "count": 1923},
    ...
  ]
}
```

### 3. GET /api/occurrences?pattern_id=custom_jwt&limit=5&offset=0
```json
{
  "occurrences": [
    {
      "pattern_id": "custom_jwt",
      "action": "added",
      "file_path": "src/auth/jwt.js",
      "line_number": 42,
      "confidence": 0.95,
      "detection_method": "regex",
      "match_text": "const signed = crypto.sign(...)",
      "repo": "microsoft/vscode",
      "created_at": "2025-01-15T10:30:00Z"
    },
    ...
  ]
}
```

### 4. GET /api/repos
```json
{
  "repos": [
    {
      "id": 1,
      "full_name": "microsoft/vscode",
      "stars": 160000,
      "language": "TypeScript",
      "commits_count": 45000,
      "occurrences_count": 127,
      "last_fetched_at": "2025-02-11T12:00:00Z"
    },
    ...
  ]
}
```

### 5. GET /api/services
```json
{
  "services": [
    {
      "name": "membria-miner",
      "status": "online",
      "cpu": 2.5,
      "memory": 145,
      "uptime": 432000
    },
    {
      "name": "membria-worker",
      "status": "online",
      "cpu": 45.2,
      "memory": 312
    },
    {
      "name": "membria-diff-loader-1",
      "status": "online"
    }
  ]
}
```

### 6. POST /api/chat
RAG chat with GLM-4-plus (for documentation/knowledge base queries)

---

## Data Storage in Membria Graph

### New Relationships to Add

```cypher
(Decision)-[USED_PATTERN {added_at, confidence}]->(AntiPattern)

(AntiPattern)-[TRIGGERED_IN {found_at, line_numbers}]->(CodeChange)

(CodeChange)-[CONTAINED_ANTIPATTERN]->(AntiPattern)

(NegativeKnowledge {blocks_pattern: "custom_jwt"})-[PREVENTED]->(Decision)
```

### New Queries to Add

```python
def antipatterns_in_team_history(pattern_id: str) -> List[Dict]:
    """How many times did our team use this pattern?"""
    # MATCH (d:Decision)-[r:USED_PATTERN]->(ap:AntiPattern {id: pattern_id})
    # RETURN count(d), collect(d.outcome)

def pattern_removal_trajectory(pattern_id: str) -> List[Dict]:
    """Timeline: when was this pattern removed?"""
    # MATCH (d:Decision)-[r:USED_PATTERN]->(ap:AntiPattern {id: pattern_id})
    # WHERE d.outcome IN ["reworked", "removed"]
    # RETURN d.resolved_at, d.outcome

def antipattern_prevention_value(pattern_id: str) -> Dict:
    """How valuable is blocking this pattern?"""
    # team_tried = count decisions with pattern
    # team_removed = count with outcome=reworked
    # prevention_rate = team_removed / team_tried
    # return {pattern_id, team_tried, team_removed, prevention_rate}
```

---

## Config & Deployment

### Environment Variables
```bash
# .env (Membria CLI)
CODEDIGGER_URL=https://codedigger.membria.ai:4000
CODEDIGGER_CACHE_TTL=86400  # 24 hours
MEMBRIA_PATTERN_CHECK_ENABLED=true
MEMBRIA_FIREWALL_LEVEL=warn  # low|warn|block|critical
MEMBRIA_PATTERN_MATCH_CONFIDENCE=0.75  # Min confidence to flag (no LLM)

# Backend (.env in backend/)
GITHUB_TOKEN=ghp_...
GLM4_API_KEY=...
DATABASE_URL=postgresql://...
REDIS_URL=redis://...
```

### CodeDigger Status
Check pipeline health before committing:
```bash
membria health --codedigger
# Shows: Miner (online), Worker (online), Diff-loaders (3/4 online), etc
```

### Git Hook Installation
```bash
membria init
# → Installs .git/hooks/pre-commit
# → Configures CodeDigger client
# → Loads patterns from API
```

### CLI Commands

```bash
# Check staged changes for antipatterns
membria antipattern-check --staged

# Show antipattern evidence
membria antipattern-evidence custom_jwt

# Show team's pattern history
membria antipattern-team-history custom_jwt

# Bypass firewall (with justification)
membria commit --allow-antipattern custom_jwt -m "Message" --reason "special case"

# View CodeDigger stats
membria stats codedigger
```

---

## Integration Points with Existing Code

### With Decision Extractor
- Detected antipatterns → Store in Decision record
- Decision + antipattern = reduced confidence?
- Show evidence to LLM during extraction

### With MCP Daemon
- Claude Code sees antipattern alerts
- Claude Code respects firewall blocks
- Claude Code links decisions to patterns

### With Graph
- Store antipattern usage in decisions
- Track removal rate over time
- Query for team-specific calibration

---

## Testing Strategy

### Unit Tests
```python
def test_detect_custom_jwt_in_code():
def test_codedigger_api_integration():
def test_evidence_formatting():
def test_pattern_matching_with_team_history():
def test_firewall_blocking_decisions():
```

### Integration Tests
```python
def test_full_antipattern_detection_flow():
    """Diff → detection → evidence → firewall decision"""

def test_pre_commit_hook_blocks_antipattern():
    """Actual git hook prevents commit"""

def test_graph_stores_antipattern_evidence():
    """Antipattern stored with link to decision"""
```

---

## Success Criteria

Phase 0.1 Complete:
- ✅ CLI can fetch patterns from CodeDigger
- ✅ CLI detects antipatterns in staged code
- ✅ Evidence shows team history
- ✅ Pre-commit hook prevents critical patterns
- ✅ Tests pass (no regressions)

Phase 0.2 Complete:
- ✅ Firewall blocks decisions based on red flags
- ✅ Escalation matrix works (Low → Critical)
- ✅ Team lead notifications sent

Phase 0.3 Complete:
- ✅ Migrations work with rollback
- ✅ Version check on startup
- ✅ Auto-migrate schema

---

## Next Steps

**User Input Needed:**

1. **CodeDigger Server Access**
   - Is it running at `http://localhost:3000`?
   - Or different host/port?
   - Any authentication needed?

2. **Prioritization**
   - Start with Phase 0.1 (CodeDigger integration)?
   - Or Phase 0.2 (Firewall first)?
   - Or Phase 0.3 (Migrations first)?

3. **Pre-Commit vs Post-Commit**
   - Block BEFORE commit (aggressive)?
   - Or alert AFTER commit (passive)?

4. **Evidence Source**
   - Show industry stats from CodeDigger?
   - Show team history from Graph?
   - Both?

---

## Why This Architecture

**Membria = Consumer of CodeDigger Intelligence**

```
CodeDigger (Backend)              Membria CLI (Frontend)
├─ Analyzes 965 repos            ├─ Consumes /api/patterns
├─ Detects 25 patterns           ├─ Loads patterns into cache
├─ 4-stage validation            ├─ Matches local diff (Stage 1-3)
├─ Removes LLM cost              ├─ Adds team history from Graph
└─ Provides REST API             └─ Enforces firewall decision

Developer tries to commit bad pattern:
┌──────────────────────────────────────────────────┐
│ Developer writes custom JWT                       │
│ → git commit                                      │
│ → pre-commit hook runs                           │
│   ├─ Loads patterns from CodeDigger (cached)     │
│   ├─ Matches in staged diff → DETECTED           │
│   ├─ Shows evidence:                              │
│   │  ├─ Industry: 89% removed (20,470 repos)    │
│   │  ├─ Team: tried 2x, removed 2x              │
│   │  └─ Alternative: passport-jwt               │
│   └─ Firewall decision: BLOCK                    │
│ ✅ Commit prevented                               │
│ Developer uses passport-jwt instead → ✅ Commit  │
└──────────────────────────────────────────────────┘
```

**Key Points:**
1. CodeDigger provides ground truth (960+ repos analyzed)
2. Membria adds context (your team's history)
3. Pre-commit hook enforces decision
4. No LLM cost (Stage 4 already cached in CodeDigger)
5. Confidence is lower without LLM (0.85 vs 0.95), but still useful
