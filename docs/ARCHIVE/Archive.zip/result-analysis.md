Критическая оценка проекта Membria-CLI
1. membria-cli-spec.md — ТЗ
Сильно:

Хорошо структурировано, покрывает все слои: CLI → MCP Daemon → Graph → Claude Code
Трёхуровневый Decision Extractor (explicit → regex → Haiku) — грамотная экономика: 90% бесплатно, LLM только для 10%
FalkorDB вместо Neo4j — правильный выбор (graph+vector в одном, in-memory)
Monty runtime для plugin-системы — минимум overhead
Проблемы:

Spec на 62KB — это не "короткое ТЗ". Это product bible. Для реализации нужен вырезанный MVP spec на 2-3 страницы
Phase 1 описывает solo dev, но spec содержит team/enterprise/SSO/RBAC — создаёт иллюзию что всё нужно сразу
Monty runtime — зависимость от Pydantic early-stage проекта (pydantic-monty). Рискованно для production
Не описана реальная инфраструктура: где работает FalkorDB? Embedded в CLI (Redis-совместимый процесс)? Docker? Отдельный сервис?
2. FINAL_BUILD_REPORT.md — Отчёт о сборке
Верифицировано по коду:

57 тестов, все проходят — подтверждено
~3500 строк кода — подтверждено (5398 с пустыми/комментами)
27 команд — подтверждено
Модульная архитектура (commands/, models, storage, graph) — чистая
Критические проблемы:

FalkorDB — mock-only. Все тесты мокают GraphClient. Ни один тест не проверяет реальное подключение к графу. Код есть, но он ни разу не был запущен против реальной БД

MCP Daemon — не integration-tested. Реализация на 415 строк есть, но тесты проверяют только CLI-команды (start/stop/status), не реальный MCP-протокол. Claude Code не подключался к этому daemon

Cypher injection в graph.py:

statement = decision.statement.replace("'", "\\'")
query = f"CREATE (d:Decision {{ id: '{decision.decision_id}', ... }})"

Ручное экранирование кавычек — уязвимость. Нужны параметризованные запросы

Hardcoded IP 192.168.0.105:6379 — внутренний адрес, не работает вне локальной сети

Haiku extractor использует claude-3-5-haiku-20241022 — это старая модель (Oct 2024). Актуальная: claude-haiku-4-5-20251001

Нет реального workflow: ни один engram не был создан на реальном проекте. Система написана, но не обкатана на себе

3. ANTIPATTERN_DETECTOR_ANALYSIS.md — Самокритика
Вердикт: аргументация в целом верна, но с оговорками.

Где документ прав:

Детектить антипаттерны в своём коде ПОСЛЕ коммита — действительно поздно
Bias detector (анализ решений) > antipattern detector (анализ кода) для personal learning
Decision → Outcome loop важнее чем code quality scanning
Где документ неправ или упрощает:

"Detecting it AFTER the fact is too late" — НЕТ. Pre-commit hook детектит ДО коммита. Это именно то, что описано в productdev.md и spec. Документ путает post-commit detection (engrams) с pre-commit prevention (Phase 1 spec)

"Humans already know about the mistake" — часто НЕТ. forEach(async) или N+1 query могут быть незаметны разработчику. Особенно если код генерировал AI

"External data is where value is" — это CodeDigger, отдельный продукт, он уже существует. Документ представляет это как альтернативу, но CodeDigger уже работает (965 repos, 155K commits, 7K+ antipatterns). Membria CLI должен ИСПОЛЬЗОВАТЬ эти данные, а не игнорировать

"Creates noise, not signal" — зависит от реализации. Если детектор блокирует custom JWT ДО коммита с показом "89% fail rate из CodeDigger" — это высокоценный signal. Документ отвергает всю концепцию из-за слабой реализации (post-commit scan)

Вывод: Самокритика Haiku хорошо написана, но защищает уже принятое решение вместо объективного анализа. Фактически Haiku убедил себя не делать то, что изначально описано в productdev.md как ключевая фича Phase 1

Общая оценка проекта
Аспект	Оценка	Комментарий
Архитектура	8/10	Чистая модульность, грамотное разделение
Код	7/10	Работает, но mock-only тесты, Cypher injection
Тесты	6/10	Количество ок, качество — тестируют CLI, не бизнес-логику
Реальная работоспособность	3/10	Ни одна интеграция не проверена на живом окружении
Spec соответствие	5/10	Spec описывает Phase 1-4, реализован только каркас Phase 1
Самокритика	7/10	Хороший анализ, но с bias к "не делать лишнего"
Главный риск: Проект выглядит завершённым на бумаге (57 тестов! 27 команд!), но ни разу не использовался на реальном проекте. FalkorDB не подключался, MCP daemon не тестировался с Claude Code, ни один engram не создан из реального коммита.

Рекомендация: Перед добавлением новых фич — запустить систему на себе. membria init → membria daemon start → сессия с Claude Code → проверить что decision записался в граф → проверить что membria decisions list показывает его.


Read and analyzed project specification and build documentation

Анализ выше — это и есть общие идеи, без каких-либо правок в коде. Ключевые мысли:

Проект хорошо спроектирован, но не обкатан — код есть, тесты проходят, но всё на моках. Ни одна реальная интеграция не проверена

Antipattern analysis документ ошибочно отвергает pre-commit detection — путает "обнаружить после коммита" с "заблокировать до коммита", хотя pre-commit prevention — это core идея из productdev.md

Spec слишком большой для Phase 1 — 62KB описывают все 4 фазы. Нужен вырезанный MVP на 2-3 страницы

Следующий шаг — не новый код, а запуск на себе (dogfooding)

Что конкретно хочешь обсудить дальше?

вчера ты сделал antipattern detector. Это длинная история - он дает статистику. Сегодня бы собрали CLI. Вопрос какой пайплайн по совместной их работе? Или antipattern detector это отдельный исследовтаельский продукт. Если цель найти какие то новые паттерны - то в детекторе нет эвристического модуля (пока); С другой стороны есть 25 паттернов которые как то должна использовать CLI ?



Хороший вопрос. Давай разберу по сути.

Что есть сейчас — два отдельных мира
CodeDigger (backend, сервер 136.114.9.4)     Membria CLI (Python, локально)
├── 965 repos                                 ├── Decision capture
├── 155K commits                              ├── Bias detector
├── 7,761 antipatterns найдено                ├── MCP daemon
├── 25 pattern definitions                    ├── FalkorDB graph
├── 4-stage detection pipeline                └── 57 тестов
│   (regex → AST → heuristic → LLM)
└── REST API на порту 4000                    Никак не связаны ↑

Три варианта пайплайна
Вариант A: CodeDigger = data source, CLI = consumer
CodeDigger (исследование)          CLI (enforcement)
├── Майнит GitHub                  ├── membria init → тянет patterns.json с API
├── Собирает статистику            ├── Pre-commit hook → проверяет diff
├── Валидирует через GLM-4.6       │   на 25 паттернов + показывает
└── Выдаёт patterns.json           │   "89% fail rate (20,470 repos)"
    с weights, stats, examples     ├── MCP daemon → инжектит в Claude Code
                                   │   "Don't use custom JWT, evidence: ..."
                                   └── Decision capture → записывает
                                       "developer overrode warning"

CLI берёт готовую статистику из CodeDigger и использует её для prevention. CodeDigger не знает про CLI. CLI не майнит GitHub.

Связь: один API endpoint — GET /api/patterns возвращает 25 паттернов со статистикой.

Вариант B: Два отдельных продукта
CodeDigger = исследовательский инструмент (дашборд, чат, аналитика).
CLI = персональная система принятия решений, вообще без антипаттернов.

Тогда антипаттерны из ANTIPATTERN_DETECTOR_ANALYSIS.md — правильно отвергнуты. CLI фокусируется только на decision → outcome loop.

Проблема: теряется главная фишка — "89% fail rate" как evidence для prevention. Bias detector без data — это просто regex по словам "definitely" и "obviously".

Вариант C: CLI = gateway ко всему
CLI тянет паттерны из CodeDigger, но также ищет новые паттерны локально (в проекте разработчика). Эвристический модуль внутри CLI.

Проблема: overengineering для Phase 1. Локальный поиск новых паттернов — это фактически дублирование CodeDigger.

Мой ответ
Вариант A — единственный который имеет смысл.

Почему:

CodeDigger уже собрал данные. Не использовать их в CLI — расточительство
CLI без evidence = пустые слова ("don't do X" без "because 89% fail")
Эвристический модуль для НОВЫХ паттернов — это Phase 2+ задача для CodeDigger, не для CLI
Связка простая: один GET endpoint, один JSON файл
Что это значит конкретно:

CodeDigger добавить:
  GET /api/patterns → [{
    id: "custom-jwt",
    name: "Custom JWT Implementation", 
    stats: { repos_seen: 20470, removal_rate: 0.89, avg_lifetime_days: 97 },
    detection: { keywords: [...], regex: [...] },
    recommendation: "Use passport-jwt"
  }, ...]

CLI добавить:
  membria init → fetch patterns.json, cache locally
  membria patterns list → показать 25 паттернов со статистикой
  membria patterns sync → обновить с сервера
  Pre-commit hook → lightweight check diff vs patterns
  MCP context → inject relevant patterns при генерации кода

А ANTIPATTERN_DETECTOR_ANALYSIS.md — документ частично неправ. Он отвергает антипаттерны целиком, потому что Haiku перепутал два use case:

Сканировать свой код пост-фактум (да, бесполезно)
Блокировать до коммита с evidence из CodeDigger (это core value)
Вопрос эвристического модуля для новых паттернов — это отдельная тема. Он нужен в CodeDigger, не в CLI. CLI потребляет, не производит patterns.

Хочешь чтобы я расписал конкретный API endpoint для CodeDigger и интеграцию в CLI?

да только коротко



API (CodeDigger, сервер)
GET /api/patterns

Возвращает:

[{
  "id": "custom-jwt",
  "name": "Custom JWT Implementation",
  "severity": "critical",
  "stats": { "repos": 20470, "removal_rate": 0.89, "avg_days": 97 },
  "detect": { "keywords": ["jwt.sign", "jwt.verify", "jsonwebtoken"] },
  "fix": "passport-jwt"
}, ...]

Один endpoint, ~25 объектов, кэшируется на сутки.

CLI (потребитель)
membria init        → fetch /api/patterns → ~/.membria/patterns.json
membria patterns    → показать список с stats
membria patterns sync → обновить

Pre-commit hook: diff содержит jwt.sign? → warning + "89% removed, avg 97 days".

MCP daemon: Claude Code генерирует код → daemon проверяет output vs patterns.json → inject warning в контекст если match.

Связка
CodeDigger (производит)     →  patterns.json  →  CLI (потребляет)
майнит, считает, валидирует    кэш на сутки      блокирует, предупреждает

Всё. Один endpoint, один файл, никакой магии.