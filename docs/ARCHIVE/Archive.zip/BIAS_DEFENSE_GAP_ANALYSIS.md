# Bias Defense Implementation Gap Analysis

**Status:** INCOMPLETE - Missing 70% of specification

---

## What's Implemented ✅

**In `bias_detector.py`:**
- Pattern matching for 4 bias types (anchoring, confirmation, overconfidence, sunk_cost)
- Risk score calculation (0-1)
- Basic recommendations (pre-mortem, devil's advocate, cool-off, etc)
- `BiasAnalysis` dataclass (biases, risk_score, gap, recommendations, severity)

**In `safety.py` commands:**
- `safety analyze <text>` - Analyze single decision
- `safety status` - Show high-risk decisions count

---

## What's Missing ❌

### 1. Anti-Bias Firewall (CRITICAL)
**From spec:** "If any of these flags are raised, the system acts as a **Brake** rather than an accelerator."

**Missing:** No firewall that BLOCKS decisions. Current code only DETECTS and RECOMMENDS.

**Need to implement:**
```python
class AntiBiasFirewall:
    def should_block_decision(self, analysis: BiasAnalysis) -> bool:
        """True if decision should be blocked/frozen."""
        # Risk score > 0.7 → BLOCK
        # Multiple red flags → BLOCK
        # Resonance > 0.6 → BLOCK
        ...
```

---

### 2. Red Flags for Manual Review

**Current:** Only risk_score (1 metric)

**Spec requires:**
| Flag | Threshold | Status |
|------|-----------|--------|
| LLM Signal Confidence < 0.7 | Too ambiguous | ❌ MISSING |
| VoI Estimate Variance > 50% | Stakeholders disagree | ❌ MISSING |
| Resonance Score > 0.6 | User-AI hallucination | ❌ MISSING |
| Cultural Context Mismatch | Communication style | ❌ MISSING |
| LoRA Confidence Adjust > 30% | Adapter override | ❌ MISSING |

**Need:**
- Collect multiple signals
- Aggregate into red flag matrix
- Score each independently
- Escalate when 2+ flags present

---

### 3. Escalation Matrix

**Spec:**
```
Severity | Condition | Action
---------|-----------|--------
Low      | Single flag, Resonance < 0.4 | Log warning
Medium   | 1-2 flags, Resonance 0.4-0.6 | Show inline alert
High     | 2+ flags OR Resonance > 0.6 | Block quick-approve, force deliberation
Critical | VoI Var > 50% + Conf < 0.7 | **FREEZE decision, escalate to team lead**
```

**Currently:** Only "low/medium/high" severity based on risk_score

**Need:**
- Escalation level (1-4)
- Action mapping (log/warn/block/freeze)
- Team lead notification
- Decision freeze mechanism

---

### 4. Detection → Intervention Map

**Spec says:**

1. **Overconfidence**
   - Trigger: Risk score > threshold
   - Action: Pre-mortem (require 3 failure scenarios)
   - Status: ❌ MISSING - only recommends, doesn't enforce

2. **Hidden Disagreement**
   - Trigger: Multiple stakeholders
   - Action: Block quick-approve, require explicit signoff
   - Status: ❌ MISSING - no stakeholder detection

3. **Anchoring**
   - Trigger: Pattern detected
   - Action: Force "Alternatives Considered" field + show historical decisions
   - Status: ⚠️  PARTIAL - detects, doesn't enforce field or show history

4. **Confirmation**
   - Trigger: Pattern detected
   - Action: Inject Devil's Advocate + surface contradicting evidence from Graph
   - Status: ⚠️  PARTIAL - recommends, doesn't query Graph for evidence

---

### 5. Response Timing Constraints

**Spec:**
- Max 2 friction interventions per decision session (prevents fatigue)
- 60 second cooldown after block before re-attempt
- 48 hour deadline for silent-party signoff before SILENCE signals expire

**Currently:** ❌ NO TIMING MECHANISM

**Need:**
- Intervention counter per session
- Cooldown tracker
- SILENCE signal expiration system

---

### 6. Graph-Backed Evidence Injection

**Spec (Confirmation bias):**
"Surface best-match contradicting evidence from Graph"

**Currently:** ❌ MISSING

**Need:**
```python
def get_contradicting_evidence(self, decision_statement: str) -> List[str]:
    """Query graph for decisions that contradict current one."""
    # Find similar decisions with opposite outcomes
    # Extract failure evidence
    # Return as "Devil's Advocate" ammunition
```

---

### 7. Missing Data Models

**In `models.py`, need:**

```python
@dataclass
class PreMortem:
    """Pre-mortem analysis."""
    failure_scenario_1: str
    failure_scenario_2: str
    failure_scenario_3: str
    probability_estimates: Dict[str, float]

@dataclass
class RedFlagSet:
    """Collection of red flags."""
    llm_confidence: float  # < 0.7 is flag
    voi_variance: float    # > 0.5 is flag
    resonance_score: float # > 0.6 is flag
    cultural_mismatch: bool
    lora_adjustment: float # > 0.3 is flag
    active_flags: List[str]
    timestamp: datetime

@dataclass
class FirewallAction:
    """What firewall decided."""
    should_block: bool
    reason: str
    escalation_level: int  # 1-4
    recommended_action: str
    team_lead_notification: bool
```

---

### 8. Missing Commands

**From spec, need:**
```bash
# Force pre-mortem
membria safety premortem <decision-id>

# Show escalation status
membria safety escalation-matrix

# Check if decision is frozen
membria safety frozen-list

# Get devil's advocate evidence
membria safety devil-advocate <decision-id>

# Require stakeholder signoff
membria safety require-signoff <decision-id> <stakeholders>
```

Currently only: `safety analyze`, `safety status`

---

## Implementation Priority

### Phase 0.2 (CRITICAL)
1. **Red Flag Detection System** - Multi-signal aggregation
   - LLM Signal Confidence tracker
   - VoI variance calculation
   - Resonance score from session analysis
   - Time: 1-2 days

2. **Anti-Bias Firewall** - Decision blocking mechanism
   - Escalation matrix (1-4 levels)
   - Block/Freeze actions
   - Team lead notification
   - Time: 1-2 days

3. **Graph-Backed Evidence** - Contradicting evidence queries
   - Find opposite-outcome similar decisions
   - Extract failure evidence
   - Inject as devil's advocate
   - Time: 1 day

### Phase 0.3 (IMPORTANT)
4. **Pre-Mortem Framework** - Enforce 3 failure scenarios
5. **Response Timing** - Intervention cooldowns
6. **Stakeholder Detection** - Multiple party awareness
7. **New safety commands** (premortem, escalation-matrix, devil-advocate, etc)

---

## Integration Points

### With Graph
- Query for similar decisions with opposite outcomes
- Store red flag history
- Track intervention count per session
- Record pre-mortem scenarios

### With MCP Daemon
- Collect LLM confidence from extraction
- Track resonance score from user feedback
- Detect stakeholder disagreement in transcript

### With CLI
- New safety commands for interventions
- Escalation alerts in all decision operations
- Block decision.record if firewall says block

---

## Files to Create/Modify

### New:
- `src/membria/firewall.py` - AntiBiasFirewall class
- `src/membria/red_flags.py` - RedFlagDetector & aggregation
- `tests/test_firewall_integration.py` - Firewall tests

### Modify:
- `src/membria/models.py` - Add PreMortem, RedFlagSet, FirewallAction
- `src/membria/bias_detector.py` - Integrate firewall & evidence
- `src/membria/commands/safety.py` - New commands
- `src/membria/graph.py` - Graph evidence queries

---

## Current State vs Spec Compliance

| Component | Spec Coverage | Status |
|-----------|---------------|--------|
| Pattern matching | 20% | ✅ Done (basic) |
| Risk scoring | 30% | ⚠️  Partial |
| Recommendations | 40% | ⚠️  Partial |
| **Red flags** | 0% | ❌ MISSING |
| **Anti-bias firewall** | 0% | ❌ MISSING |
| **Escalation matrix** | 0% | ❌ MISSING |
| **Graph evidence** | 0% | ❌ MISSING |
| **Pre-mortem** | 0% | ❌ MISSING |
| **Timing constraints** | 0% | ❌ MISSING |
| **Stakeholder detection** | 0% | ❌ MISSING |

**Overall:** ~15% complete

---

## Why This Matters

Current system:
- ✅ Detects biases
- ✅ Recommends interventions
- ❌ **Never blocks** even obvious bad decisions
- ❌ **No escalation** for critical situations
- ❌ **No evidence** from past failures

Spec system should:
- ✅ Detect biases
- ✅ Recommend interventions
- ✅ **BLOCK bad decisions** (firewall)
- ✅ **ESCALATE critical ones** (team lead)
- ✅ **SHOW evidence** from Graph
- ✅ **ENFORCE** deliberation before quick-approve

---

## Next Steps

1. Read full [Cognitive Safety & LLM Bias Firewall](/cognitive-safety) architecture
2. Implement RedFlagDetector (collects 5 signals)
3. Implement AntiBiasFirewall (blocks decisions)
4. Create firewall integration tests
5. Add Graph evidence queries
6. New CLI commands
