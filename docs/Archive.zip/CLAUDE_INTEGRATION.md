# Claude Code Integration Guide

## Overview

Membria integrates with Claude Code through the Model Context Protocol (MCP). This enables Claude to:

- Capture and analyze your coding decisions
- Provide calibrated context based on team history
- Validate plans before implementation
- Track decision outcomes for continuous learning

## Quick Start

### 1. Install Membria

```bash
cd /Users/miguelaprossine/membria-cli
pip install -e .
```

### 2. Configure Claude Code

Add to your Claude Code settings (`~/.claude/settings.json` or via UI):

```json
{
  "mcp_servers": {
    "membria": {
      "type": "stdio",
      "command": "python",
      "args": ["-m", "membria.mcp_server"],
      "cwd": "/Users/miguelaprossine/membria-cli"
    }
  }
}
```

### 3. Start Using in Claude Code

Claude now has access to all Membria tools. Example:

```
User: "I'm thinking of using PostgreSQL for the user database.
Can you check if this is a good decision in our context?"

Claude (internally):
  1. Calls membria.get_decision_context
  2. Receives: calibration data, past decisions, patterns
  3. Responds with informed recommendation
```

## Available Tools

### 1. membria.capture_decision

**When to use:** Before making architectural decisions

```
Tool Call:
{
  "statement": "Use PostgreSQL for user database",
  "alternatives": ["MongoDB", "MySQL", "DynamoDB"],
  "confidence": 0.8,
  "context": {
    "module": "database"
  }
}

Response:
{
  "decision_id": "dec_abc123...",
  "status": "pending",
  "message": "Decision captured"
}
```

**Use case:**
```
Claude: "I'll use PostgreSQL for the user database"
Claude (internally): Calls capture_decision() to record this
Response: Decision tracked in Membria graph
```

---

### 2. membria.record_outcome

**When to use:** After 30 days or when decision impact is clear

```
Tool Call:
{
  "decision_id": "dec_abc123...",
  "final_status": "success",
  "final_score": 0.95,
  "decision_domain": "database"
}

Response:
{
  "outcome_id": "out_xyz789...",
  "decision_id": "dec_abc123...",
  "calibration_impact": {
    "domain": "database",
    "sample_size": 15,
    "success_rate": 0.87
  }
}
```

**Use case:**
```
30 days after decision:
Claude: "Let's review how the PostgreSQL decision went"
Claude (internally): Calls record_outcome()
Result: CalibrationProfile updated, team confidence refined
```

---

### 3. membria.get_calibration

**When to use:** To understand team bias in a domain

```
Tool Call:
{
  "domain": "auth"
}

Response:
{
  "domain": "auth",
  "sample_size": 25,
  "success_rate": 0.82,
  "confidence_gap": 0.08,
  "trend": "improving",
  "note": "Team is slightly overconfident - reduce time estimates by 10-15%"
}
```

**Use case:**
```
Claude: "How confident is the team with authentication decisions?"
Response: Shows overconfidence pattern, recommends padding time estimates
```

---

### 4. membria.get_decision_context

**When to use:** Before making a decision, to get relevant history

```
Tool Call:
{
  "statement": "Use JWT for authentication",
  "module": "auth",
  "confidence": 0.75
}

Response:
{
  "decision_statement": "Use JWT for authentication",
  "module": "auth",
  "your_confidence": 0.75,
  "calibration_context": {
    "past_success_rate": 0.92,
    "confidence_gap": 0.05,
    "recommendations": [...]
  }
}
```

---

### 5. membria.get_plan_context (NEW - PRE-PLAN)

**When to use:** BEFORE planning (enables informed planning)

```
Tool Call:
{
  "domain": "auth",
  "scope": "JWT implementation with refresh tokens"
}

Response:
{
  "domain": "auth",
  "formatted": "# Plan Context: AUTH\n\n## Team Calibration\n...",
  "total_tokens": 1234,
  "past_plans": [...],
  "failed_approaches": [...],
  "successful_patterns": [...],
  "calibration": {...},
  "constraints": ["Uses TypeScript", "Docker containerized", ...],
  "recommendations": [...]
}
```

**Use case:**
```
Claude: "Let me plan the authentication system"
Claude (internally): Calls get_plan_context()
Result: Gets rich context about past auth plans, known failures,
        team calibration before starting to plan
Response: Much better plan because it's informed by history
```

---

### 6. membria.validate_plan (NEW - MID-PLAN)

**When to use:** AFTER generating a plan, BEFORE executing

```
Tool Call:
{
  "steps": [
    "Set up Fastify server",
    "Implement JWT authentication",
    "Add refresh token mechanism"
  ],
  "domain": "auth"
}

Response:
{
  "total_steps": 3,
  "warnings_count": 1,
  "high_severity": 0,
  "can_proceed": true,
  "warnings": [
    {
      "step": 2,
      "type": "past_failure",
      "severity": "medium",
      "message": "Similar approach failed before",
      "suggestion": "Consider why it failed last time"
    }
  ]
}
```

**Use case:**
```
Claude: "Here's my plan: [3 steps]. Ready to code?"
Claude (internally): Calls validate_plan()
If warnings: Refines plan based on history
Response: Approved plan with learned insights
```

---

### 7. membria.record_plan (NEW - POST-PLAN)

**When to use:** When plan is finalized and approved

```
Tool Call:
{
  "plan_steps": [
    "Set up database",
    "Create API endpoints",
    "Add authentication"
  ],
  "domain": "auth",
  "plan_confidence": 0.85,
  "duration_estimate": "3 hours",
  "warnings_shown": 2,
  "warnings_heeded": 1
}

Response:
{
  "engram_id": "eng_abc123...",
  "domain": "auth",
  "plan_steps": 3,
  "decisions_recorded": [...],
  "status": "recorded"
}
```

---

## Usage Patterns

### Pattern 1: Decision Context + Capture

```
User: "Should we use Auth0 or implement JWT ourselves?"

Claude (internally):
  1. get_decision_context("JWT vs Auth0", "auth", confidence=0.7)
  2. Sees: "Custom JWT failed 2x, Auth0: 12 successes"
  3. Captures decision: capture_decision(...)

Response: "I recommend Auth0 because the team has 12 successful
uses compared to 2 failures with custom JWT"
```

### Pattern 2: Plan Mode Flow (PRE → MID → POST)

```
User: "Plan the authentication system"

Claude (internally):
  1. [PRE-PLAN] get_plan_context("auth", "JWT + refresh")
     → Gets past plans, failures, patterns, calibration

  2. Generates informed plan

  3. [MID-PLAN] validate_plan(steps, "auth")
     → Checks against NK, AP, past failures, calibration

  4. Refines plan if needed

  5. [POST-PLAN] record_plan(finalized_steps, "auth")
     → Captures all decisions in engram

Result: Complete closed-loop learning
```

### Pattern 3: Continuous Calibration

```
Day 1: Capture database architecture decision
Day 30: Record outcome (success)
Day 31: Calibration updated
Day 32: Next database decision gets refined context

Result: Team gets better over time as Membria learns
```

## Examples

### Example 1: Get Auth Context

```
User: "What do we know about authentication decisions?"

Behind the scenes:
  get_calibration("auth") →
  {
    "success_rate": 0.85,
    "confidence_gap": 0.08,
    "sample_size": 20,
    "note": "⚠️ OVERCONFIDENT by 8% - Pad time estimates significantly"
  }

Claude responds: "Our auth decisions succeed 85% of the time,
but we tend to overestimate our confidence. Past successful patterns:
- Auth0 integration (12 uses, 100%)
- JWT + Redis sessions (8 uses, 88%)
- Firebase auth (0 uses yet)"
```

### Example 2: Validate a Plan

```
User: "Here's my plan: 1) Custom JWT 2) Rate limiting 3) Audit logs"

Behind the scenes:
  validate_plan([...], "auth") →
  {
    "warnings": [
      {
        "step": 1,
        "message": "Custom JWT implementation failed 2x before",
        "suggestion": "Use Auth0 or Passport-JWT instead"
      }
    ]
  }

Claude responds: "I see a potential issue with step 1.
Custom JWT has failed twice before in this context.
Would you consider Auth0 or an established library instead?"
```

## Architecture

```
Claude Code
    ↓
MCP Protocol (stdio)
    ↓
membria/mcp_server.py
    ↓
├─ PlanContextBuilder (PRE-PLAN)
├─ PlanValidator (MID-PLAN)
├─ SkillGenerator
├─ PatternExtractor
├─ CalibrationUpdater
└─ GraphClient → FalkorDB
```

## Configuration

### Environment Variables

```bash
# Optional: Configure FalkorDB connection
export FALKORDB_HOST=localhost
export FALKORDB_PORT=6379
export FALKORDB_PASSWORD=your_password
```

### Settings File

Create `~/.claudemembriarc` for persistent settings:

```ini
[graph]
host = localhost
port = 6379
db = membria

[logging]
level = INFO

[features]
enable_plan_mode = true
enable_calibration_warnings = true
```

## Troubleshooting

### MCP Server won't start

```bash
# Check if Python path is correct
which python

# Test import
python -c "from membria.mcp_server import MembriaMCPServer; print('OK')"

# Start with verbose logging
PYTHONPATH=/Users/miguelaprossine/membria-cli python -m membria.mcp_server
```

### Claude doesn't see tools

1. Check `~/.claude/settings.json` has correct config
2. Restart Claude Code
3. Check logs: `tail -f ~/.claude/logs/mcp.log`

### FalkorDB connection error

```bash
# Check if FalkorDB is running
redis-cli ping

# Or start with Docker
docker run -d --name falkordb -p 6379:6379 falkordb/falkordb:latest
```

## Next Steps

1. **Configure Claude Code** - Add to settings.json
2. **Test the connection** - Ask Claude a decision question
3. **Use Plan Mode** - Let Claude help you plan with context
4. **Track outcomes** - Record what worked/didn't work
5. **Watch calibration improve** - See team confidence refine

## Support

For issues or questions:
- Check logs: `python -m membria.mcp_server` with verbose output
- Read examples in `/examples` folder
- Check test files: `tests/test_mcp_*.py`
