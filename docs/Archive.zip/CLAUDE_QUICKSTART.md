# Подключение Membria к Claude - Быстрый Старт

**Время:** 10 минут на настройку + 5 минут первое использование

---

## Шаг 1️⃣ Запустить MCP Сервер

В терминале:

```bash
cd ~/Developer/membria-cli
source venv/bin/activate
python src/membria/start_mcp_server.py
```

**Должно появиться:**
```
✅ MCP Server running on http://localhost:6379
Press Ctrl+C to stop
```

**Оставить это окно открытым!** Сервер должен работать когда вы используете Claude.

---

## Шаг 2️⃣ Проверить что сервер работает

В **другом** терминальном окне:

```bash
curl http://localhost:6379/health
```

**Должен вернуть:**
```json
{"status":"ok"}
```

Если не работает - проверьте что Python активирован и сервер действительно запущен.

---

## Шаг 3️⃣ Настроить Claude

### Вариант A: В Claude Code (Рекомендуется)

Если используете Claude Code (VSCode):

1. Откройте свой рабочий проект в VSCode
2. Создайте папку `.claude`:
   ```bash
   mkdir -p .claude
   ```

3. Создайте файл `.claude/claude.json`:
   ```bash
   touch .claude/claude.json
   ```

4. Откройте файл и вставьте:
   ```json
   {
     "mcp_servers": {
       "membria": {
         "command": "python",
         "args": [
           "/Users/ВашИмя/Developer/membria-cli/src/membria/start_mcp_server.py"
         ],
         "env": {}
       }
     }
   }
   ```

5. **ВАЖНО:** Замените `/Users/ВашИмя` на ваше имя!

   Узнать своё имя:
   ```bash
   whoami
   ```

6. Сохраните файл (Cmd+S)

7. Перезагрузите Claude Code окно (Cmd+Shift+P → "Reload Window")

### Вариант B: В веб Claude (claude.ai)

К сожалению, веб версия Claude не поддерживает локальные MCP серверы. Нужно использовать Claude Code (VSCode расширение).

---

## Шаг 4️⃣ Проверить что работает

В Claude Code начните разговор:

```
User: "What decision intelligence tools do you have available?"
```

**Claude должен ответить:**
```
I have access to Membria decision intelligence tools:
- capture_decision
- record_outcome
- get_calibration
- get_decision_context
- validate_plan
- record_plan
- get_plan_context
```

Если видите этот список - **всё работает!** 🎉

---

## Шаг 5️⃣ Использовать Membria в Claude

### Пример 1: Capture Decision

```
User: "I'm planning to use PostgreSQL for the user database.
       Help me decide - should I use PostgreSQL, MongoDB, or DynamoDB?"

Claude: [Будет использовать capture_decision tool]

Claude: "I've captured your decision. Let me also check what
        your team has experienced with these choices..."

Claude: [Будет использовать get_calibration tool]

Claude: "Based on your team's history:
        - PostgreSQL: 89% success rate (24 decisions)
        - MongoDB: 71% success rate (12 decisions)
        - DynamoDB: 65% success rate (8 decisions)

        Recommendation: PostgreSQL is your strongest choice."
```

### Пример 2: Get Context

```
User: "I need context for using Redis for caching"

Claude: [Будет использовать get_decision_context tool]

Claude: "Here's what your team knows about Redis caching:
        - Success rate: 92%
        - Recent similar decisions: [list]
        - Known issues: [list]
        - Calibration gap: +5% (team slightly overconfident)"
```

### Пример 3: Validate Plan

```
User: "Here's my plan for auth system redesign:
       1. Migrate from custom JWT to Auth0
       2. Keep existing refresh tokens
       3. Deploy to production immediately

       Is this plan safe?"

Claude: [Будет использовать validate_plan tool]

Claude: "I've validated your plan. Found some issues:
        ⚠️ HIGH: Refresh token incompatibility detected
        ⚠️ MEDIUM: No rollback plan mentioned
        ✅ Migrate to Auth0 is a known success pattern

        Recommendation: Add rollback procedure before deploying"
```

---

## 📚 Доступные Команды в Claude

### 1. `capture_decision`
**Используется для:** Записи нового решения

**Параметры:**
- `statement` - что решили (например: "Use PostgreSQL")
- `alternatives` - альтернативы (массив)
- `confidence` - уверенность от 0 до 1

**Пример в Claude:**
```
User: "I've decided to use Redis instead of Memcached.
       I'm 80% confident this is right."

Claude: [Автоматически использует capture_decision]
```

### 2. `record_outcome`
**Используется для:** Записи результата решения

**Параметры:**
- `decision_id` - ID решения
- `status` - результат (success, failure, partial)
- `score` - оценка от 0 до 1

**Пример в Claude:**
```
User: "The PostgreSQL migration was successful.
       Everything went well."

Claude: [Автоматически использует record_outcome]
```

### 3. `get_decision_context`
**Используется для:** Получения информации о прошлых решениях

**Параметры:**
- `statement` - о чём нужна информация
- `module` - область (optional)
- `confidence` - ваша уверенность

**Пример в Claude:**
```
User: "What does the team know about caching strategies?"

Claude: [Использует get_decision_context]
→ Returns recent decisions, success rates, warnings
```

### 4. `validate_plan`
**Используется для:** Проверки плана на опасности

**Параметры:**
- `steps` - шаги плана
- `domain` - область (optional)

**Пример в Claude:**
```
User: "Should I validate this database migration plan?"

Claude: [Использует validate_plan]
→ Checks against known failures, antipatterns, calibration
```

### 5. `record_plan`
**Используется для:** Сохранения плана в систему

**Параметры:**
- `plan_steps` - шаги плана
- `domain` - область
- `confidence` - уверенность в плане

**Пример в Claude:**
```
User: "Save this migration plan for future reference"

Claude: [Использует record_plan]
→ Plan stored in Membria
```

### 6. `get_calibration`
**Используется для:** Получения калибрации команды

**Параметры:**
- `domain` - область (optional)

**Пример в Claude:**
```
User: "How well calibrated is our team in database decisions?"

Claude: [Использует get_calibration]
→ Shows success rate, confidence gap, trends
```

### 7. `get_plan_context`
**Используется для:** Получения контекста для планирования

**Параметры:**
- `domain` - область
- `scope` - область применения (optional)

**Пример в Claude:**
```
User: "Give me context for planning a caching system"

Claude: [Использует get_plan_context]
→ Returns past plans, patterns, recommendations
```

---

## 🔧 Настройка (Advanced)

### Изменить Порт MCP Сервера

По умолчанию сервер работает на порту `6379`.

Если нужен другой порт, отредактируйте `.claude/claude.json`:

```json
{
  "mcp_servers": {
    "membria": {
      "command": "python",
      "args": [
        "/Users/ВашИмя/Developer/membria-cli/src/membria/start_mcp_server.py",
        "--port", "5000"
      ]
    }
  }
}
```

### Добавить Переменные Окружения

```json
{
  "mcp_servers": {
    "membria": {
      "command": "python",
      "args": ["..."],
      "env": {
        "MEMBRIA_DEBUG": "true",
        "MEMBRIA_LOG_LEVEL": "debug"
      }
    }
  }
}
```

### Установить Timeout

```json
{
  "mcp_servers": {
    "membria": {
      "command": "python",
      "args": ["..."],
      "timeout": 30000
    }
  }
}
```

---

## ❌ Решение Проблем

### Проблема: "MCP server not found"

**Решение:**
1. Проверьте что файл `.claude/claude.json` существует:
   ```bash
   ls -la .claude/claude.json
   ```

2. Проверьте что путь правильный:
   ```bash
   whoami  # Узнайте ваше имя
   ls -la /Users/ВашИмя/Developer/membria-cli/
   ```

3. Перезагрузите Claude Code:
   - Cmd+Shift+P → "Reload Window"

### Проблема: "Connection refused"

**Решение:**
1. Убедитесь что MCP Сервер запущен:
   ```bash
   curl http://localhost:6379/health
   ```

2. Если не работает - запустите сервер:
   ```bash
   cd ~/Developer/membria-cli
   source venv/bin/activate
   python src/membria/start_mcp_server.py
   ```

3. Оставьте это окно открытым!

### Проблема: "Python not found"

**Решение:**
1. Проверьте что Python установлена:
   ```bash
   which python3
   python3 --version
   ```

2. Используйте полный путь в `.claude/claude.json`:
   ```json
   {
     "command": "/usr/bin/python3",
     "args": [...]
   }
   ```

   Узнать полный путь:
   ```bash
   which python3
   ```

### Проблема: Tools не показываются в Claude

**Решение:**
1. Убедитесь что MCP Сервер работает:
   ```bash
   curl http://localhost:6379/health
   ```

2. Перезагрузите Claude Code:
   - Cmd+Shift+P → "Reload Window"

3. Начните новый разговор (старый разговор может не показывать tools)

4. Проверьте что `.claude/claude.json` синтаксически правильный:
   ```bash
   python3 -c "import json; json.load(open('.claude/claude.json'))"
   # Не должно быть ошибок
   ```

---

## 📊 Рабочий Процесс

### День 1: Первая Настройка
```
1. Запустить MCP Сервер (в фоне)
2. Настроить .claude/claude.json
3. Перезагрузить Claude Code
4. Проверить что tools доступны
```

### День 2+: Каждое Использование
```
1. Убедиться что MCP Сервер запущен
   (должно быть окно терминала с "MCP Server running")

2. Использовать Claude для:
   - Планирования решений
   - Проверки планов
   - Получения контекста
   - Записи результатов
```

---

## ✅ Контрольный Список

- [ ] MCP Сервер установлен и работает
- [ ] Файл `.claude/claude.json` создан в рабочем проекте
- [ ] Путь в конфиге правильный (замен на ваше имя)
- [ ] Claude Code перезагружен
- [ ] Tools видны в новом разговоре
- [ ] Первая команда (`capture_decision`) работает
- [ ] `curl http://localhost:6379/health` возвращает `{"status":"ok"}`

---

## 🚀 Готово!

Теперь Membria доступна в Claude Code!

**Используйте:**
```
User: "Help me plan database migration.
       What has the team tried before?"

Claude: [Использует Membria tools автоматически]
→ get_decision_context("database migration")
→ get_calibration("database")
→ get_plan_context("database")

Claude: "Based on Membria data, here's what I found:
        - 23 past database decisions
        - Team success rate: 87% in database domain
        - You're slightly overconfident by 5%

        Recommendation: PostgreSQL has 91% success rate"
```

---

## 📚 Дополнительная Информация

Более подробная информация в:
- `membria-cli/docs/CLAUDE_INTEGRATION.md` - полное описание всех tools
- `INTEGRATION_GUIDE.md` - как всё работает вместе
- `MACOS_SETUP_GUIDE.md` - общая инструкция установки

---

**Статус:** ✅ Готово к использованию
**Дата:** 2026-02-11
**Версия:** 1.0.0
