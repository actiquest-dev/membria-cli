# Membria на Mac - Полная Инструкция Запуска

Пошаговое руководство по установке и запуску всей системы на macOS.

## 📋 Требования

- macOS 10.14+ (Mojave или новее)
- 4GB RAM минимум
- 500MB свободного места
- Интернет соединение

---

## Этап 1: Установка Prerequisites

### 1.1 Проверить Python

```bash
# Проверить установлена ли Python 3
python3 --version
# Должно показать: Python 3.8 или выше
```

**Если Python не установлена:**
```bash
# Вариант 1: Через Homebrew (рекомендуется)
brew install python@3.11

# Вариант 2: Скачать с python.org
# https://www.python.org/downloads/

# После установки проверить:
python3 --version
```

### 1.2 Проверить Node.js

```bash
# Проверить установлена ли Node
node --version
npm --version
# Должно показать v18 или выше (npm 9+)
```

**Если Node не установлена:**
```bash
# Способ 1: Через Homebrew (проще)
brew install node

# Способ 2: Через nvm (можно управлять версиями)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
nvm install 18
nvm use 18

# Проверить
node --version
npm --version
```

### 1.3 Установить Git

```bash
# Проверить есть ли Git
git --version
# Должно показать git version 2.x или выше
```

**Если Git не установлен:**
```bash
brew install git
```

### 1.4 Установить VSCode

```bash
# Проверить установлен ли VSCode
code --version
# Должно показать версию 1.85+
```

**Если VSCode не установлен:**
1. Скачать с https://code.visualstudio.com/
2. Перетащить в Applications папку
3. Запустить из Applications

### 1.5 Установить Homebrew (если нужно)

```bash
# Проверить есть ли Homebrew
brew --version

# Если нет, установить:
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

---

## Этап 2: Клонировать Membria

### 2.1 Выбрать папку для проектов

```bash
# Перейти в домашнюю папку
cd ~

# Создать папку для проектов (если её нет)
mkdir -p Developer
cd Developer
```

### 2.2 Клонировать репозиторий

```bash
# Клонировать Membria CLI
git clone https://github.com/miguelaprossine/membria-cli.git
cd membria-cli

# Проверить что клонировалось
ls -la
# Должны быть: src/, tests/, pyproject.toml, README.md
```

---

## Этап 3: Установить Membria CLI

### 3.1 Создать виртуальное окружение

```bash
# Убедиться что в папке membria-cli
pwd
# Должно показать: /Users/ВашИмя/Developer/membria-cli

# Создать виртуальное окружение Python
python3 -m venv venv

# Активировать его
source venv/bin/activate

# Должно показать в начале строки: (venv)
# Если нет - попробуйте: source venv/bin/activate
```

### 3.2 Установить зависимости

```bash
# Убедиться что (venv) активно
# Обновить pip
pip install --upgrade pip setuptools wheel

# Установить Membria
pip install -e .

# Должна быть Success сообщение в конце
```

### 3.3 Проверить установку

```bash
# Проверить что установилось
membria --version
membria --help

# Должны увидеть список команд
```

---

## Этап 4: Запустить MCP Сервер

### 4.1 В новом терминальном окне

```bash
# Открыть новый tab в Terminal: Cmd+T

# Перейти в папку membria-cli
cd ~/Developer/membria-cli

# Активировать viртуальное окружение
source venv/bin/activate

# Запустить сервер
python src/membria/start_mcp_server.py

# Должно показать:
# ✅ MCP Server running on http://localhost:6379
# Нажать Ctrl+C чтобы остановить (потом снова запустить)
```

**Оставить это окно открытым!** Сервер должен работать всегда когда используете Membria.

### 4.2 Проверить что сервер работает

В **другом** терминальном окне:

```bash
# В новом tab: Cmd+T

# Проверить что сервер доступен
curl http://localhost:6379/health

# Должно показать: {"status":"ok"}
```

---

## Этап 5: Настроить VSCode Extension

### 5.1 Открыть папку extension

```bash
# В том же терминале где проверили здоровье сервера

# Перейти в папку extension
cd ~/Developer/membria-cli/vscode-extension

# Открыть в VSCode
code .
```

VSCode откроется с папкой extension загруженной.

### 5.2 Установить зависимости

В VSCode:

```bash
# Нажать Ctrl+` чтобы открыть встроенный терминал VSCode

# Должны быть в: .../vscode-extension

# Установить npm пакеты
npm install

# Это займет 1-2 минуты
# Должно быть: "added X packages"
```

### 5.3 Скомпилировать TypeScript

```bash
# В том же терминале VSCode

npm run compile

# Должно быть: без ошибок, создана папка "out"
```

### 5.4 Запустить extension в debug режиме

```bash
# Нажать F5 в VSCode

# Или: Run → Start Debugging (в меню)
```

Откроется **новое окно VSCode** с загруженным extension'ом!

### 5.5 Проверить что extension работает

В **новом окне VSCode** (с extension'ом):

```bash
# Нажать Cmd+Shift+P для Command Palette

# Тип: "membria"

# Должны увидеть список команд:
# - Membria: Capture Decision
# - Membria: Get Context
# - Membria: Validate Plan
# - и т.д.
```

Отлично! Extension работает! 🎉

### 5.6 Тестировать команды

Попробовать команду (всё ещё в новом окне с extension'ом):

```bash
# Нажать Cmd+Shift+M D

# Введите: "Use PostgreSQL for user database"

# Нажмите Enter

# Должно появиться сообщение: "Decision captured: ..."
```

---

## Этап 6: Настроить Claude Code (Опционально)

Если используете Claude Code для работы с Membria.

### 6.1 Создать конфигурацию

В своём проекте создать файл `.claude/claude.json`:

```bash
# В вашем рабочем проекте
mkdir -p .claude
touch .claude/claude.json
```

### 6.2 Добавить конфигурацию

Содержимое `.claude/claude.json`:

```json
{
  "mcp_servers": {
    "membria": {
      "command": "python",
      "args": [
        "/Users/ВашИмя/Developer/membria-cli/src/membria/start_mcp_server.py"
      ]
    }
  }
}
```

**Важно:** Заменить `/Users/ВашИмя` на ваше имя пользователя Mac!

Узнать своё имя:
```bash
whoami
# Покажет ваше имя, например: john
```

### 6.3 Проверить что работает

В Claude Code:
```
User: "Help me plan a database redesign"

Claude: [должен использовать Membria tools]
```

---

## Полная Схема Запуска (После Установки)

**Каждый раз когда хотите работать с Membria:**

### Шаг 1️⃣ Запустить MCP Сервер (Terminal окно 1)

```bash
cd ~/Developer/membria-cli
source venv/bin/activate
python src/membria/start_mcp_server.py
# Оставить открытым!
```

### Шаг 2️⃣ Открыть VSCode Extension (Terminal окно 2)

```bash
cd ~/Developer/membria-cli/vscode-extension
code .
# Нажать F5 в VSCode
```

Откроется новое окно VSCode с extension'ом.

### Шаг 3️⃣ Использовать Membria

**В новом окне VSCode (с extension'ом):**
- `Cmd+Shift+M D` - Capture Decision
- `Cmd+Shift+M V` - Validate Plan
- `Cmd+Shift+M O` - Record Outcome
- И т.д.

**Или в Claude Code:**
- Использовать Membria tools в разговоре

---

## 🔧 Полезные Команды

### Проверить статус

```bash
# Проверить Python
python3 --version

# Проверить Node
node --version
npm --version

# Проверить Git
git --version

# Проверить что сервер работает
curl http://localhost:6379/health
```

### Работать с virtualenv

```bash
# Активировать окружение (из папки membria-cli)
source venv/bin/activate

# Деактивировать
deactivate

# Удалить и переустановить (если что-то сломалось)
rm -rf venv
python3 -m venv venv
source venv/bin/activate
pip install -e .
```

### Работать с npm

```bash
# Убедиться что в папке vscode-extension

# Переустановить зависимости
rm -rf node_modules package-lock.json
npm install

# Очистить build
npm run clean

# Перекомпилировать
npm run compile

# Запустить тесты
npm test
```

### Убить процесс на порту 6379

Если сервер не хочет запускаться:

```bash
# Найти процесс на порту 6379
lsof -i :6379

# Убить процесс (замените 12345 на PID из вывода выше)
kill -9 12345

# Или просто
killall python
```

---

## ❌ Решение Проблем

### Проблема: "command not found: python3"

```bash
# Установить Python через Homebrew
brew install python@3.11

# Проверить
python3 --version
```

### Проблема: "npm ERR! code EACCES"

```bash
# Проблема с правами. Решение:
sudo chown -R $(whoami) ~/.npm
npm install
```

### Проблема: "MCP Server connection refused"

```bash
# Убедиться что сервер запущен в другом окне терминала
# Проверить порт
lsof -i :6379

# Если выход пуст - сервер не запущен
# Запустить его:
cd ~/Developer/membria-cli
source venv/bin/activate
python src/membria/start_mcp_server.py
```

### Проблема: "Extension won't activate in VSCode"

```bash
# Переустановить зависимости
cd ~/Developer/membria-cli/vscode-extension
rm -rf node_modules out
npm install
npm run compile

# Перезагрузить VSCode (F5 или Cmd+R в debug окне)
```

### Проблема: "Cannot find module 'axios'"

```bash
# В папке vscode-extension
npm install axios
npm run compile
```

### Проблема: Port 6379 already in use

```bash
# Найти что использует порт
lsof -i :6379

# Убить процесс
kill -9 <PID>

# Или изменить порт в start_mcp_server.py и перезапустить
```

---

## 📚 Структура Папок

После установки структура будет такая:

```
~/Developer/
├── membria-cli/
│   ├── venv/                           # Python виртуальное окружение
│   ├── src/membria/
│   │   ├── start_mcp_server.py         # MCP Server (запускаем это)
│   │   ├── skill_generator.py
│   │   ├── behavior_chains.py
│   │   └── commands/
│   │       ├── plan_commands.py
│   │       └── skill_commands.py
│   ├── vscode-extension/       # VSCode Extension
│   │   ├── src/
│   │   ├── package.json
│   │   └── tsconfig.json
│   ├── .claude/
│   │   └── claude.json                 # Claude Config (создаём)
│   └── README.md
└── .claude/
    └── claude.json                     # Config в вашем проекте (опционально)
```

---

## ✅ Контрольный Список Установки

Отметить когда завершено:

- [ ] Python 3.8+ установлена
- [ ] Node.js 18+ установлена
- [ ] VSCode установлен
- [ ] Git установлен
- [ ] Membria CLI клонирована
- [ ] Виртуальное окружение создано и активировано
- [ ] Membria CLI установлена (`pip install -e .`)
- [ ] MCP Сервер запущен и работает (`curl localhost:6379/health`)
- [ ] VSCode Extension npm пакеты установлены
- [ ] VSCode Extension скомпилирована (`npm run compile`)
- [ ] Extension работает в debug режиме (F5)
- [ ] Команды видны в Command Palette
- [ ] Хотя бы одна команда протестирована

---

## 🚀 Быстрый Старт (Для Тех Кто Уже Установил)

```bash
# Терминал 1: MCP Сервер
cd ~/Developer/membria-cli
source venv/bin/activate
python src/membria/start_mcp_server.py

# Терминал 2: VSCode Extension
cd ~/Developer/membria-cli/vscode-extension
code . &&
# Нажать F5 в VSCode
```

Готово! 🎉

---

## 📞 Помощь

Если что-то не работает:

1. Проверить что **все требования установлены**:
   ```bash
   python3 --version
   node --version
   git --version
   code --version
   ```

2. Убедиться что **MCP Сервер запущен**:
   ```bash
   curl http://localhost:6379/health
   ```

3. Проверить **логи**:
   - MCP Сервер: посмотреть в терминале где запустили
   - VSCode Extension: View → Output → Membria

4. Прочитать **документацию**:
   - `vscode-extension/README.md`
   - `vscode-extension/DEVELOPMENT.md`
   - `vscode-extension/SETUP_CHECKLIST.md`

---

## Версии

- **macOS:** 10.14+ (Mojave или новее)
- **Python:** 3.8 или выше
- **Node.js:** 14 или выше
- **VSCode:** 1.85 или выше
- **Membria:** 1.0.0

**Обновлено:** 2026-02-11
