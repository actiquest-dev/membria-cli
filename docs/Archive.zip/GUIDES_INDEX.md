# Membria - Полный Индекс Документации

Быстрая навигация по всем гайдам и инструкциям.

---

## 🚀 Для Новичков (Начните Отсюда)

### 1. Установка на macOS
📄 **[MACOS_SETUP_GUIDE.md](MACOS_SETUP_GUIDE.md)**
- Пошаговая установка Python, Node.js, VSCode
- Запуск MCP Сервера
- Настройка VSCode Extension
- Решение проблем на Mac

**Время:** 30-60 минут

### 2. Быстрый Старт (5 минут)
📄 **[INTEGRATION_COMPLETE.md](INTEGRATION_COMPLETE.md)**
- Обзор всех трёх интеграций
- Quick Start команды
- Проверка что установилось

**Время:** 5-10 минут

---

## 📚 Детальные Гайды

### VSCode Extension

#### Для Пользователей
📄 **[vscode-extension/README.md](vscode-extension/README.md)**
- Обзор функций
- Установка extension
- Все команды (9 штук)
- Sidebar views (4 штуки)
- Hover context и decorations
- Troubleshooting

**Время для чтения:** 20 минут

#### Для Разработчиков
📄 **[vscode-extension/DEVELOPMENT.md](vscode-extension/DEVELOPMENT.md)**
- Setup для разработки
- Как собирать и тестировать
- Архитектура компонентов
- Как добавить новую команду
- Debugging tips
- Performance tips

**Время для чтения:** 30 минут

#### Полная Интеграция
📄 **[vscode-extension/INTEGRATION_GUIDE.md](vscode-extension/INTEGRATION_GUIDE.md)**
- Архитектура всей системы
- Три точки интеграции
- Complete workflow пример
- Configuration reference
- Security & performance

**Время для чтения:** 40 минут

#### Статус Реализации
📄 **[vscode-extension/COMPLETION_STATUS.md](vscode-extension/COMPLETION_STATUS.md)**
- Что реализовано
- Что можно улучшить
- Статистика кода
- Success metrics

**Время для чтения:** 15 минут

#### Setup Чеклист
📄 **[vscode-extension/SETUP_CHECKLIST.md](vscode-extension/SETUP_CHECKLIST.md)**
- Контрольный список установки
- Manual testing checklist
- Packaging инструкции
- Troubleshooting guide

**Время для чтения:** 15 минут

### Claude Code Интеграция

📄 **[membria-cli/docs/CLAUDE_INTEGRATION.md](membria-cli/docs/CLAUDE_INTEGRATION.md)**
- 7 MCP tools
- Примеры использования
- API reference
- Troubleshooting

**Время для чтения:** 30 минут

### VSCode Tasks Интеграция

📄 **[membria-cli/docs/VSCODE_INTEGRATION.md](membria-cli/docs/VSCODE_INTEGRATION.md)**
- 11 configured tasks
- 7 keyboard shortcuts
- Configuration files
- Automation examples

**Время для чтения:** 20 минут

---

## 🎯 Гайды по Сценариям

### Сценарий: "Я новичок и хочу просто попробовать"

1. Прочитайте: [MACOS_SETUP_GUIDE.md](MACOS_SETUP_GUIDE.md)
2. Следуйте пошаговым инструкциям
3. Попробуйте команду `Ctrl+Shift+M D` (Capture Decision)
4. Готово! 🎉

**Время:** 1 час

### Сценарий: "Я разработчик и хочу улучшить extension"

1. Прочитайте: [vscode-extension/DEVELOPMENT.md](vscode-extension/DEVELOPMENT.md)
2. Изучите: [vscode-extension/INTEGRATION_GUIDE.md](vscode-extension/INTEGRATION_GUIDE.md)
3. Запустите в debug режиме: `F5`
4. Делайте изменения в `src/`
5. Тестируйте

**Время:** зависит от изменений

### Сценарий: "Я хочу использовать Membria в Claude Code"

1. Прочитайте: [membria-cli/docs/CLAUDE_INTEGRATION.md](membria-cli/docs/CLAUDE_INTEGRATION.md)
2. Запустите: `python src/membria/start_mcp_server.py`
3. Настройте: `.claude/claude.json`
4. Используйте в Claude: 7 tools

**Время:** 30 минут

### Сценарий: "Я хочу автоматизировать VSCode"

1. Прочитайте: [membria-cli/docs/VSCODE_INTEGRATION.md](membria-cli/docs/VSCODE_INTEGRATION.md)
2. Настройте: `.vscode/tasks.json` и `.vscode/keybindings.json`
3. Используйте: `Ctrl+Shift+M` + буква

**Время:** 15 минут

### Сценарий: "У меня что-то не работает"

1. Прочитайте: [MACOS_SETUP_GUIDE.md](MACOS_SETUP_GUIDE.md) секция "Решение Проблем"
2. Прочитайте: [vscode-extension/README.md](vscode-extension/README.md) секция "Troubleshooting"
3. Проверьте logи: View → Output → Membria

**Время:** 10-20 минут

---

## 📊 Структура Документации

### Установка & Запуск
```
MACOS_SETUP_GUIDE.md          ← НАЧНИТЕ ОТСЮДА
├─ Требования
├─ Пошаговая установка
├─ Проверка каждого шага
├─ Запуск MCP Сервера
├─ Настройка Extension
├─ Настройка Claude
└─ Решение проблем
```

### VSCode Extension (5 гайдов)
```
vscode-extension/
├─ README.md                  ← Пользователям
├─ DEVELOPMENT.md             ← Разработчикам
├─ INTEGRATION_GUIDE.md       ← Полная архитектура
├─ COMPLETION_STATUS.md       ← Что реализовано
└─ SETUP_CHECKLIST.md         ← Тестирование
```

### Интеграции (3 гайда)
```
membria-cli/docs/
├─ CLAUDE_INTEGRATION.md      ← Claude Code
├─ VSCODE_INTEGRATION.md      ← VSCode Tasks
└─ INTEGRATION_GUIDE.md       ← Все вместе
```

### Финальные Документы
```
INTEGRATION_COMPLETE.md       ← Обзор всех трёх частей
GUIDES_INDEX.md              ← Этот файл
```

---

## 🔍 Поиск по Темам

### Как Установить?
- [MACOS_SETUP_GUIDE.md](MACOS_SETUP_GUIDE.md) - полная инструкция

### Как Использовать Extension?
- [vscode-extension/README.md](vscode-extension/README.md) - все команды и views
- [vscode-extension/SETUP_CHECKLIST.md](vscode-extension/SETUP_CHECKLIST.md) - тестирование

### Как Разрабатывать Extension?
- [vscode-extension/DEVELOPMENT.md](vscode-extension/DEVELOPMENT.md) - setup и debugging
- [vscode-extension/INTEGRATION_GUIDE.md](vscode-extension/INTEGRATION_GUIDE.md) - архитектура

### Как Использовать в Claude?
- [membria-cli/docs/CLAUDE_INTEGRATION.md](membria-cli/docs/CLAUDE_INTEGRATION.md) - 7 tools с примерами

### Как Использовать VSCode Tasks?
- [membria-cli/docs/VSCODE_INTEGRATION.md](membria-cli/docs/VSCODE_INTEGRATION.md) - 11 tasks и shortcuts

### Как Запустить Локально?
- [MACOS_SETUP_GUIDE.md](MACOS_SETUP_GUIDE.md) - пошагово с проверками

### Как Отладить Проблемы?
- [MACOS_SETUP_GUIDE.md](MACOS_SETUP_GUIDE.md) "Решение Проблем"
- [vscode-extension/README.md](vscode-extension/README.md) "Troubleshooting"
- [vscode-extension/DEVELOPMENT.md](vscode-extension/DEVELOPMENT.md) "Debugging Tips"

### Какие Команды Доступны?
- [vscode-extension/README.md](vscode-extension/README.md) "Commands"
- [membria-cli/docs/VSCODE_INTEGRATION.md](membria-cli/docs/VSCODE_INTEGRATION.md) "Available Tasks"
- [membria-cli/docs/CLAUDE_INTEGRATION.md](membria-cli/docs/CLAUDE_INTEGRATION.md) "Available Tools"

---

## 📈 Рекомендуемый Порядок Чтения

### Для Новичков
1. **5 минут:** [INTEGRATION_COMPLETE.md](INTEGRATION_COMPLETE.md) - обзор
2. **30 минут:** [MACOS_SETUP_GUIDE.md](MACOS_SETUP_GUIDE.md) - установка
3. **20 минут:** [vscode-extension/README.md](vscode-extension/README.md) - как использовать

**Итого:** ~1 час

### Для Разработчиков
1. **5 минут:** [INTEGRATION_COMPLETE.md](INTEGRATION_COMPLETE.md) - обзор
2. **30 минут:** [MACOS_SETUP_GUIDE.md](MACOS_SETUP_GUIDE.md) - установка
3. **40 минут:** [vscode-extension/INTEGRATION_GUIDE.md](vscode-extension/INTEGRATION_GUIDE.md) - архитектура
4. **30 минут:** [vscode-extension/DEVELOPMENT.md](vscode-extension/DEVELOPMENT.md) - разработка

**Итого:** ~1.5 часа

### Для Использования в Claude
1. **5 минут:** [INTEGRATION_COMPLETE.md](INTEGRATION_COMPLETE.md) - обзор
2. **30 минут:** [MACOS_SETUP_GUIDE.md](MACOS_SETUP_GUIDE.md) - установка
3. **30 минут:** [membria-cli/docs/CLAUDE_INTEGRATION.md](membria-cli/docs/CLAUDE_INTEGRATION.md) - tools

**Итого:** ~1 час

---

## ✅ Контрольный Список: Что Прочитать

### Базовый Уровень (Обязательно)
- [ ] [MACOS_SETUP_GUIDE.md](MACOS_SETUP_GUIDE.md) - как установить и запустить
- [ ] [vscode-extension/README.md](vscode-extension/README.md) - как использовать

### Продвинутый Уровень
- [ ] [vscode-extension/DEVELOPMENT.md](vscode-extension/DEVELOPMENT.md) - если будете разрабатывать
- [ ] [membria-cli/docs/CLAUDE_INTEGRATION.md](membria-cli/docs/CLAUDE_INTEGRATION.md) - если будете использовать в Claude
- [ ] [membria-cli/docs/VSCODE_INTEGRATION.md](membria-cli/docs/VSCODE_INTEGRATION.md) - если будете использовать Tasks

### Для Полного Понимания
- [ ] [vscode-extension/INTEGRATION_GUIDE.md](vscode-extension/INTEGRATION_GUIDE.md) - полная архитектура
- [ ] [vscode-extension/COMPLETION_STATUS.md](vscode-extension/COMPLETION_STATUS.md) - что реализовано

---

## 🎯 Быстрые Ссылки

| Что хочу | Где читать | Время |
|---------|----------|------|
| Установить на Mac | [MACOS_SETUP_GUIDE.md](MACOS_SETUP_GUIDE.md) | 30 мин |
| Быстро начать | [INTEGRATION_COMPLETE.md](INTEGRATION_COMPLETE.md) | 5 мин |
| Использовать extension | [vscode-extension/README.md](vscode-extension/README.md) | 20 мин |
| Разработать extension | [vscode-extension/DEVELOPMENT.md](vscode-extension/DEVELOPMENT.md) | 30 мин |
| Использовать в Claude | [membria-cli/docs/CLAUDE_INTEGRATION.md](membria-cli/docs/CLAUDE_INTEGRATION.md) | 30 мин |
| Использовать Tasks | [membria-cli/docs/VSCODE_INTEGRATION.md](membria-cli/docs/VSCODE_INTEGRATION.md) | 20 мин |
| Полная архитектура | [vscode-extension/INTEGRATION_GUIDE.md](vscode-extension/INTEGRATION_GUIDE.md) | 40 мин |
| Найти ответ на вопрос | [GUIDES_INDEX.md](GUIDES_INDEX.md) (этот файл) | 5 мин |

---

## 📞 Если Что-то Не Работает

1. **Проверить установку:** [MACOS_SETUP_GUIDE.md](MACOS_SETUP_GUIDE.md) → "Решение Проблем"
2. **Проверить extension:** [vscode-extension/README.md](vscode-extension/README.md) → "Troubleshooting"
3. **Проверить Claude:** [membria-cli/docs/CLAUDE_INTEGRATION.md](membria-cli/docs/CLAUDE_INTEGRATION.md) → "Troubleshooting"
4. **Проверить logи:** View → Output → Membria

---

## 📅 История Обновлений

| Дата | Что добавлено |
|------|--------------|
| 2026-02-11 | Все гайды созданы |
| 2026-02-11 | MACOS_SETUP_GUIDE.md |
| 2026-02-11 | GUIDES_INDEX.md (этот файл) |

---

## 💡 Рекомендации

### Для Первого Запуска
1. Прочитайте [MACOS_SETUP_GUIDE.md](MACOS_SETUP_GUIDE.md)
2. Следуйте пошаговым инструкциям (не пропускайте!)
3. Проверяйте каждый шаг перед переходом дальше

### Для Каждодневной Работы
1. Запустите MCP Сервер: `python src/membria/start_mcp_server.py`
2. Откройте VSCode с extension'ом: `code . && F5`
3. Используйте команды: `Ctrl+Shift+M` + буква

### Для Отладки
1. Проверьте что сервер работает: `curl http://localhost:6379/health`
2. Проверьте логи: View → Output → Membria
3. Перезагрузите extension: `Cmd+R` в debug окне

---

## 📚 Структура Всех Документов

```
/Users/miguelaprossine/
├── MACOS_SETUP_GUIDE.md              ← Как установить
├── INTEGRATION_COMPLETE.md           ← Обзор всех интеграций
├── GUIDES_INDEX.md                   ← ВЫ ЗДЕСЬ
│
├── membria-cli/
│   ├── docs/
│   │   ├── CLAUDE_INTEGRATION.md     ← Claude Code
│   │   └── VSCODE_INTEGRATION.md     ← VSCode Tasks
│   └── README.md                     ← Основной README
│
└── vscode-extension/
    ├── README.md                     ← Extension для пользователей
    ├── DEVELOPMENT.md                ← Extension для разработчиков
    ├── INTEGRATION_GUIDE.md          ← Полная архитектура
    ├── COMPLETION_STATUS.md          ← Статус реализации
    └── SETUP_CHECKLIST.md            ← Тестирование
```

---

**Обновлено:** 2026-02-11
**Версия:** 1.0.0
**Статус:** ✅ Полная документация готова
