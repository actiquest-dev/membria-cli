# 👋 Начните Отсюда

Добро пожаловать в Membria! Выберите что вам нужно:

---

## 🚀 Мне нужно установить и запустить

**Время:** 30-60 минут

→ **[MACOS_SETUP_GUIDE.md](MACOS_SETUP_GUIDE.md)**

Полная пошаговая инструкция по установке на Mac с проверкой каждого шага.

---

## 🤖 Я хочу использовать Membria в Claude

**Время:** 10 минут

→ **[CLAUDE_QUICKSTART.md](CLAUDE_QUICKSTART.md)**

Быстрая настройка подключения к Claude Code с примерами использования.

---

## ⚙️ Мне нужна детальная документация

**Время:** варьируется

→ **[GUIDES_INDEX.md](GUIDES_INDEX.md)**

Полный индекс всех документов с навигацией по темам.

---

## 📋 Мне нужна информация про...

| Тема | Ссылка |
|------|--------|
| **Установка** | [MACOS_SETUP_GUIDE.md](MACOS_SETUP_GUIDE.md) |
| **Быстрое подключение Claude** | [CLAUDE_QUICKSTART.md](CLAUDE_QUICKSTART.md) |
| **Все tools в Claude** | [CLAUDE_INTEGRATION.md](CLAUDE_INTEGRATION.md) |
| **VSCode Tasks & shortcuts** | [VSCODE_INTEGRATION.md](VSCODE_INTEGRATION.md) |
| **VSCode Extension** | ../vscode-extension/README.md |
| **Разработка extension** | ../vscode-extension/DEVELOPMENT.md |
| **Архитектура системы** | ../vscode-extension/INTEGRATION_GUIDE.md |
| **Решение проблем** | [MACOS_SETUP_GUIDE.md](MACOS_SETUP_GUIDE.md) → Решение Проблем |
| **Все гайды (индекс)** | [GUIDES_INDEX.md](GUIDES_INDEX.md) |

---

## 🗂️ Структура папки docs/

```
docs/
├── 00_START_HERE.md              ← ВЫ ЗДЕСЬ
├── README.md                      ← Обзор документации
├── MACOS_SETUP_GUIDE.md          ← Полная установка
├── CLAUDE_QUICKSTART.md          ← Быстрое подключение
├── CLAUDE_INTEGRATION.md         ← Детали Claude tools
├── VSCODE_INTEGRATION.md         ← VSCode Tasks
└── GUIDES_INDEX.md               ← Полный индекс
```

---

## ⚡ Самое Быстрое Начало (5 минут)

**Если уже установлен Python, Node.js и VSCode:**

```bash
# 1. Запустить сервер (в одном терминале)
cd ~/Developer/membria-cli
source venv/bin/activate
python src/membria/start_mcp_server.py

# 2. Открыть extension (в другом терминале)
cd ~/Developer/membria-cli/vscode-extension
code . 
# Нажать F5

# 3. Использовать в Claude
# Добавить в .claude/claude.json:
{
  "mcp_servers": {
    "membria": {
      "command": "python",
      "args": ["/Users/ВашИмя/Developer/membria-cli/src/membria/start_mcp_server.py"]
    }
  }
}
```

**Готово!** 🎉

---

## ❓ Часто Задаваемые Вопросы

**Q: С чего начать?**
A: → [MACOS_SETUP_GUIDE.md](MACOS_SETUP_GUIDE.md)

**Q: Как подключить к Claude?**
A: → [CLAUDE_QUICKSTART.md](CLAUDE_QUICKSTART.md)

**Q: Как использовать в VSCode?**
A: → ../vscode-extension/README.md

**Q: Что-то не работает?**
A: → [MACOS_SETUP_GUIDE.md](MACOS_SETUP_GUIDE.md) → Решение Проблем

**Q: Нужны примеры?**
A: → [GUIDES_INDEX.md](GUIDES_INDEX.md) → Примеры

---

**Выбирайте нужный гайд и начинайте! ⬆️**

Если вопросы - [GUIDES_INDEX.md](GUIDES_INDEX.md) поможет найти ответ.

---

**Версия:** 1.0.0 | **Дата:** 2026-02-11
